// My Bookings & Ticket Cancellation Management
let activeBookingsList = [];

document.addEventListener('DOMContentLoaded', async () => {
  if (!requireAuth()) return;
  await loadMyBookings();
});

async function loadMyBookings() {
  const container = document.getElementById('my-bookings-container');
  if (!container) return;

  container.innerHTML = `
    <div style="text-align: center; padding: 3rem;">
      <p style="font-size: 1.1rem; color: var(--gray-500);">⏳ Fetching your booking history...</p>
    </div>
  `;

  try {
    const res = await API.get('/api/bookings/my-bookings');
    activeBookingsList = res.bookings || [];

    if (activeBookingsList.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; background: var(--white); padding: 3.5rem; border-radius: var(--radius-lg); border: 1px solid var(--gray-200);">
          <div style="font-size: 3rem; margin-bottom: 0.5rem;">🎟️</div>
          <h3 style="font-size: 1.3rem; margin-bottom: 0.5rem; color: var(--gray-800);">No bookings found</h3>
          <p style="color: var(--gray-500); margin-bottom: 1.5rem;">You haven't booked any bus tickets yet.</p>
          <a href="index.html" class="btn btn-primary">Search & Book Buses</a>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 1.5rem;">
        ${activeBookingsList.map(renderBookingCard).join('')}
      </div>
    `;

  } catch (err) {
    container.innerHTML = `
      <div style="background: var(--danger-light); color: var(--danger); padding: 1.5rem; border-radius: var(--radius-md); text-align: center;">
        ${err.message || 'Error loading bookings.'}
      </div>
    `;
  }
}

function renderBookingCard(b) {
  const isConfirmed = b.booking_status === 'CONFIRMED';
  const depTime = formatDateTime(b.departure_time);
  const arrTime = formatDateTime(b.arrival_time);
  const seatNums = b.passengers.map(p => p.seat_number).join(', ');

  return `
    <div class="bus-card" style="grid-template-columns: 2fr 3fr 1.5fr auto; align-items: start;">
      <div>
        <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
          <span style="font-size: 1.1rem; font-weight: 800; color: var(--primary); letter-spacing: 0.5px;">${b.pnr}</span>
          <span class="badge ${isConfirmed ? 'badge-success' : 'badge-danger'}">
            ${b.booking_status}
          </span>
        </div>
        <h4 style="font-size: 1.1rem; color: var(--gray-900); margin-bottom: 0.2rem;">${b.bus_name}</h4>
        <div style="font-size: 0.825rem; color: var(--gray-500);">Reg: ${b.bus_number} • ${b.bus_type}</div>
        <div style="font-size: 0.8rem; color: var(--gray-400); margin-top: 0.4rem;">Booked on ${formatDateTime(b.booking_date)}</div>
      </div>

      <div>
        <div class="bus-timeline" style="margin-bottom: 1rem;">
          <div class="time-box">
            <div class="time">${depTime.split(',')[1] || depTime}</div>
            <div class="city">${b.source}</div>
            <div style="font-size: 0.75rem; color: var(--gray-400);">${depTime.split(',')[0]}</div>
          </div>

          <div class="duration-line">
            <div class="duration">${b.estimated_duration}</div>
            <div class="line"></div>
          </div>

          <div class="time-box">
            <div class="time">${arrTime.split(',')[1] || arrTime}</div>
            <div class="city">${b.destination}</div>
            <div style="font-size: 0.75rem; color: var(--gray-400);">${arrTime.split(',')[0]}</div>
          </div>
        </div>

        <div style="background: var(--gray-50); padding: 0.75rem; border-radius: var(--radius-md); font-size: 0.85rem;">
          <div style="font-weight: 600; color: var(--gray-700); margin-bottom: 0.3rem;">
            Seats (${b.passengers.length}): <span style="color: var(--primary); font-weight: 700;">${seatNums}</span>
          </div>
          <div style="color: var(--gray-500); font-size: 0.8rem;">
            ${b.passengers.map(p => `${p.passenger_name} (${p.passenger_age}y, Seat ${p.seat_number})`).join(' • ')}
          </div>
        </div>
      </div>

      <div class="bus-pricing" style="text-align: right;">
        <div class="price">${formatCurrency(b.total_fare)}</div>
        <div style="font-size: 0.75rem; color: var(--gray-400); margin-top: 0.2rem;">Txn: ${b.transaction_id || 'N/A'}</div>
        ${!isConfirmed ? `
          <div style="margin-top: 0.5rem; font-size: 0.8rem; color: var(--danger); font-weight: 600;">
            Refunded: ${formatCurrency(b.refund_amount || 0)}
          </div>
        ` : ''}
      </div>

      <div style="display: flex; flex-direction: column; gap: 0.5rem; align-items: flex-end;">
        ${isConfirmed ? `
          ${b.canCancel ? `
            <button class="btn btn-danger btn-sm" onclick="openCancelModal(${b.id})">
              Cancel Ticket
            </button>
            <div style="font-size: 0.75rem; color: var(--gray-500); text-align: right; max-width: 140px;">
              ${b.hoursUntilDeparture}h to depart<br>
              <strong>${b.eligibleRefundPercent}% Refund</strong>
            </div>
          ` : `
            <span class="badge badge-warning" style="font-size: 0.75rem;">Departed (Non-refundable)</span>
          `}
        ` : `
          <span class="badge badge-danger">Cancelled & Refunded</span>
        `}
      </div>
    </div>
  `;
}

// Open Cancellation Confirmation Modal with Refund calculation
function openCancelModal(bookingId) {
  const booking = activeBookingsList.find(b => b.id === bookingId);
  if (!booking) return;

  const modal = document.getElementById('cancel-confirm-modal');
  const content = document.getElementById('cancel-modal-content');

  content.innerHTML = `
    <div style="text-align: center; margin-bottom: 1.25rem;">
      <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">⚠️</div>
      <h3 style="font-size: 1.3rem; color: var(--gray-900);">Confirm Ticket Cancellation</h3>
      <p style="color: var(--gray-500); font-size: 0.875rem;">Are you sure you want to cancel booking <strong>${booking.pnr}</strong>?</p>
    </div>

    <div style="background: var(--gray-50); border-radius: var(--radius-md); padding: 1.25rem; margin-bottom: 1.5rem; font-size: 0.9rem;">
      <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
        <span style="color: var(--gray-600);">Total Ticket Amount:</span>
        <span style="font-weight: 700;">${formatCurrency(booking.total_fare)}</span>
      </div>
      <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
        <span style="color: var(--gray-600);">Hours to Departure:</span>
        <span style="font-weight: 700;">${booking.hoursUntilDeparture} hours</span>
      </div>
      <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
        <span style="color: var(--gray-600);">Refund Policy Tier:</span>
        <span style="font-weight: 700; color: var(--primary);">${booking.eligibleRefundPercent}% Refund</span>
      </div>
      <div style="display: flex; justify-content: space-between; border-top: 1px solid var(--gray-200); padding-top: 0.5rem; font-size: 1.05rem;">
        <span style="font-weight: 700; color: var(--gray-800);">Estimated Refund:</span>
        <span style="font-weight: 800; color: var(--success);">${formatCurrency(booking.estimatedRefund)}</span>
      </div>
    </div>

    <p style="font-size: 0.775rem; color: var(--gray-400); margin-bottom: 1.25rem; text-align: center;">
      * Cancelling will immediately release seats <strong>${booking.passengers.map(p => p.seat_number).join(', ')}</strong> back to public availability.
    </p>

    <div style="display: flex; gap: 0.75rem;">
      <button class="btn btn-secondary" style="flex: 1;" onclick="closeCancelModal()">Keep Ticket</button>
      <button class="btn btn-danger" style="flex: 1;" onclick="executeCancellation(${bookingId})">Yes, Cancel & Refund</button>
    </div>
  `;

  modal.classList.add('active');
}

function closeCancelModal() {
  const modal = document.getElementById('cancel-confirm-modal');
  if (modal) modal.classList.remove('active');
}

async function executeCancellation(bookingId) {
  try {
    const res = await API.post(`/api/bookings/${bookingId}/cancel`, {});
    closeCancelModal();
    showToast(`Cancelled! Refund of ${formatCurrency(res.cancellation.refund_amount)} processed.`, 'success');
    await loadMyBookings();
  } catch (err) {
    showToast(err.message, 'error');
  }
}
