-- ====================================================================
-- Bus Ticket Booking System - Database Schema (SQLite 3NF)
-- Designed for College DBMS Project & Technical Viva
-- ====================================================================

PRAGMA foreign_keys = ON;

-- 1. USERS TABLE
-- Stores credentials and user profiles with role-based authorization
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    phone TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user', 'admin')),
    created_at DATETIME DEFAULT (datetime('now', 'localtime'))
);

-- 2. BUSES TABLE
-- Stores physical bus fleet information
CREATE TABLE IF NOT EXISTS buses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bus_number TEXT UNIQUE NOT NULL,
    bus_name TEXT NOT NULL,
    bus_type TEXT NOT NULL CHECK(bus_type IN ('AC Sleeper', 'Non-AC Sleeper', 'AC Seater', 'Non-AC Seater')),
    total_seats INTEGER NOT NULL DEFAULT 40 CHECK(total_seats > 0),
    created_at DATETIME DEFAULT (datetime('now', 'localtime'))
);

-- 3. ROUTES TABLE
-- Stores travel routes with origin and destination pairs
CREATE TABLE IF NOT EXISTS routes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT NOT NULL COLLATE NOCASE,
    destination TEXT NOT NULL COLLATE NOCASE,
    distance_km REAL NOT NULL CHECK(distance_km > 0),
    estimated_duration TEXT NOT NULL,
    created_at DATETIME DEFAULT (datetime('now', 'localtime')),
    UNIQUE(source, destination)
);

-- 4. SCHEDULES TABLE
-- Connects a bus to a route on a specific departure date/time
CREATE TABLE IF NOT EXISTS schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bus_id INTEGER NOT NULL REFERENCES buses(id) ON DELETE CASCADE,
    route_id INTEGER NOT NULL REFERENCES routes(id) ON DELETE CASCADE,
    departure_time TEXT NOT NULL, -- ISO Format: YYYY-MM-DD HH:MM:SS
    arrival_time TEXT NOT NULL,   -- ISO Format: YYYY-MM-DD HH:MM:SS
    fare REAL NOT NULL CHECK(fare >= 0),
    status TEXT NOT NULL DEFAULT 'scheduled' CHECK(status IN ('scheduled', 'completed', 'cancelled')),
    created_at DATETIME DEFAULT (datetime('now', 'localtime')),
    CHECK(arrival_time > departure_time)
);

-- 5. SEATS TABLE
-- Static physical seat layout blueprint for each bus (1 to 40)
CREATE TABLE IF NOT EXISTS seats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bus_id INTEGER NOT NULL REFERENCES buses(id) ON DELETE CASCADE,
    seat_number TEXT NOT NULL,
    seat_type TEXT NOT NULL CHECK(seat_type IN ('window', 'aisle')),
    deck TEXT NOT NULL DEFAULT 'lower' CHECK(deck IN ('lower', 'upper')),
    UNIQUE(bus_id, seat_number)
);

-- 6. BOOKINGS TABLE
-- Represents a completed booking header with a unique PNR
CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pnr TEXT UNIQUE NOT NULL,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    schedule_id INTEGER NOT NULL REFERENCES schedules(id) ON DELETE CASCADE,
    total_fare REAL NOT NULL CHECK(total_fare >= 0),
    status TEXT NOT NULL DEFAULT 'CONFIRMED' CHECK(status IN ('CONFIRMED', 'CANCELLED')),
    booking_date DATETIME DEFAULT (datetime('now', 'localtime'))
);

-- 7. BOOKING_PASSENGERS TABLE
-- Detail table storing each passenger assigned to a specific seat for a schedule
CREATE TABLE IF NOT EXISTS booking_passengers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    schedule_id INTEGER NOT NULL REFERENCES schedules(id) ON DELETE CASCADE,
    seat_number TEXT NOT NULL,
    passenger_name TEXT NOT NULL,
    passenger_age INTEGER NOT NULL CHECK(passenger_age > 0),
    passenger_gender TEXT NOT NULL CHECK(passenger_gender IN ('Male', 'Female', 'Other')),
    status TEXT NOT NULL DEFAULT 'CONFIRMED' CHECK(status IN ('CONFIRMED', 'CANCELLED'))
);

-- 8. PAYMENTS TABLE
-- Mock payment record storing transaction, payment method, and refund details
CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    amount REAL NOT NULL CHECK(amount >= 0),
    payment_method TEXT NOT NULL DEFAULT 'MOCK_UPI',
    transaction_id TEXT UNIQUE NOT NULL,
    status TEXT NOT NULL DEFAULT 'SUCCESS' CHECK(status IN ('SUCCESS', 'REFUNDED', 'PARTIAL_REFUND')),
    refund_amount REAL DEFAULT 0.0 CHECK(refund_amount >= 0),
    created_at DATETIME DEFAULT (datetime('now', 'localtime'))
);

-- ====================================================================
-- PERFORMANCE INDEXES & CONCURRENCY CONSTRAINTS
-- ====================================================================

-- Critical Unique Partial Index to prevent double booking active seats
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_active_seat 
ON booking_passengers(schedule_id, seat_number) 
WHERE status = 'CONFIRMED';

-- Search Performance Index for source & destination route matching
CREATE INDEX IF NOT EXISTS idx_routes_source_dest 
ON routes(source, destination);

-- Search Performance Index for schedules by route and departure timestamp
CREATE INDEX IF NOT EXISTS idx_schedules_search 
ON schedules(route_id, departure_time, status);

-- User Bookings History Index
CREATE INDEX IF NOT EXISTS idx_bookings_user 
ON bookings(user_id, booking_date DESC);
