# 🚌 Bus Ticket Booking System (DBMS + Full-Stack Backend Project)

A complete, beginner-friendly, production-grade **Bus Ticket Booking System** engineered for college DBMS laboratory projects, backend technical demonstrations, and viva examinations.

---

## 🌟 Key Features

1. **User Authentication & Authorization**:
   - Secure signup, login, and profile fetching with **JWT (JSON Web Tokens)** and **bcrypt** password hashing.
   - Role-Based Access Control (`user` vs `admin`).
2. **Dynamic Bus Search**:
   - Search buses by origin, destination, and travel date.
   - Instant calculation of real-time seat availability (`total_seats - confirmed_seats`).
3. **Interactive Visual Seat Grid**:
   - 2x2 realistic bus layout (40 seats across 10 rows with driver cabin and central aisle).
   - Booked seats are greyed out and unclickable; available seats are selectable.
   - Supports selecting multiple seats (up to 6 per booking).
4. **Multi-Passenger Booking & PNR Generation**:
   - Dynamic passenger form (Name, Age, Gender) per selected seat.
   - Generates a unique, collision-free PNR ticket (e.g., `PNR-7K9A2X`).
5. **My Bookings & Smart Cancellation**:
   - Chronological list of user's past and upcoming bookings.
   - **Automated Refund Calculation**:
     - $> 24$ hours before departure: **100% Refund**.
     - $0$ to $24$ hours before departure: **50% Refund**.
     - After departure: **0% Refund (Non-refundable)**.
   - Cancelling instantly releases seats back to other passengers.
6. **Role-Protected Admin Management Portal**:
   - System dashboard with live revenue, fleet, and occupancy statistics.
   - Full CRUD operations for **Buses**, **Routes**, and **Trip Schedules**.
   - System-wide booking auditor with passenger breakdowns.

---

## 🛠️ Tech Stack

- **Backend**: Node.js & Express.js
- **Database**: SQLite (via `better-sqlite3` / native SQLite engine) with `schema.sql` and seeding script
- **Security**: JWT (`jsonwebtoken`) + Password Hashing (`bcryptjs`)
- **Frontend**: Plain HTML5, Modern CSS3 (Variables, Flexbox, Grid), and Vanilla ES6+ JavaScript (zero external frameworks)

---

## 📂 Project Directory Structure

```
bus-ticket-booking-system/
├── backend/
│   ├── config/
│   │   └── db.js               # SQLite connection, WAL mode & foreign keys enabled
│   ├── controllers/
│   │   ├── authController.js   # User registration, login, profile logic
│   │   ├── busController.js    # Search routes, departure schedules, seat blueprints
│   │   ├── bookingController.js# Transaction-safe seat booking & refund cancellation
│   │   └── adminController.js  # Fleet, routes, schedules CRUD & revenue analytics
│   ├── db/
│   │   ├── schema.sql          # 3NF SQLite database schema with constraints & indexes
│   │   └── seed.js             # Initializer script with 10 buses, 5 routes, demo users
│   ├── middleware/
│   │   ├── auth.js             # JWT verification and Admin role validation
│   │   └── errorHandler.js     # Standardized JSON error response handler
│   ├── routes/
│   │   ├── authRoutes.js       # /api/auth endpoints
│   │   ├── busRoutes.js        # /api/buses endpoints
│   │   ├── bookingRoutes.js    # /api/bookings endpoints
│   │   └── adminRoutes.js      # /api/admin endpoints
│   └── server.js               # Express application entrypoint
├── frontend/
│   ├── css/
│   │   └── styles.css          # Modern clean design system & responsive layout
│   ├── js/
│   │   ├── api.js              # Centralized fetch wrapper & toast notifications
│   │   ├── auth.js             # Authentication state & navbar renderer
│   │   ├── search.js           # Bus search & bus cards renderer
│   │   ├── booking.js          # 2x2 visual seat grid & passenger checkout
│   │   ├── my-bookings.js      # Booking history & refund cancellation modal
│   │   └── admin.js            # Admin dashboard: buses, routes, schedules, bookings
│   ├── index.html              # Search buses & home portal
│   ├── seat-selection.html     # Interactive 2x2 seat selection canvas
│   ├── my-bookings.html        # Customer booking management
│   ├── admin.html              # Role-protected Admin dashboard
│   ├── login.html              # Login page (with 1-click demo login buttons)
│   └── register.html           # New account registration
├── docs/
│   ├── schema_er_diagram.md    # Mermaid ER Diagram & relational mappings
│   ├── sample_queries.sql      # 5 advanced viva queries (JOIN, GROUP BY, aggregations)
│   └── dbms_concepts.md        # Comprehensive 3NF, ACID, transactions & indexing viva notes
├── .env.example
├── .env
├── package.json
└── README.md
```

---

## 🚀 Setup & Installation Steps

### Prerequisites
- Node.js (v18 or higher recommended)
- npm

### 1. Install Dependencies
```bash
npm install
```

### 2. Seed the Database
Populates 1 Admin, 2 Demo Users, 5 Popular Routes, 10 Buses, 400 Seats, and 44 Trip Schedules:
```bash
npm run seed
```

### 3. Start the Application
```bash
npm start
```
The server will start at: **`http://localhost:5000`**

---

## 🔑 Demo Credentials (1-Click Fill in UI)

| Role | Email | Password | Access Rights |
| :--- | :--- | :--- | :--- |
| **System Admin** | `admin@busbooking.com` | `Admin@123` | Full Admin Dashboard & Fleet CRUD |
| **Demo User 1** | `rahul@example.com` | `User@123` | Search, Book, Cancel & History |
| **Demo User 2** | `priya@example.com` | `User@123` | Search, Book, Cancel & History |

---

## 🧠 DBMS Concepts Used (For College Viva)

### 1. Relational Database Normalization (3NF)
- **1NF**: Every field holds atomic values; no comma-separated seat lists.
- **2NF**: No partial functional dependencies; separated `routes`, `buses`, and `schedules`.
- **3NF**: Eliminated transitive dependencies; passenger records and payments are normalized in separate tables linked by Foreign Keys.

### 2. ACID Transactions
- Seat booking and ticket cancellation are wrapped in atomic SQL transactions (`db.transaction(...)`).
- If 2 users attempt to book the last available seat simultaneously, the first to commit succeeds; the second receives a clean concurrency collision error, and the database automatically rolls back.

### 3. Integrity Constraints
- **Primary & Foreign Keys**: `ON DELETE CASCADE` ensures clean referential integrity.
- **CHECK Constraints**:
  - `CHECK(role IN ('user', 'admin'))`
  - `CHECK(fare >= 0)`
  - `CHECK(arrival_time > departure_time)`
  - `CHECK(passenger_age > 0)`
- **Partial Unique Index (Double-Booking Prevention)**:
  ```sql
  CREATE UNIQUE INDEX idx_unique_active_seat 
  ON booking_passengers(schedule_id, seat_number) 
  WHERE status = 'CONFIRMED';
  ```

### 4. Database Indexing (B-Tree Performance)
- `idx_routes_source_dest` on `routes(source, destination)`
- `idx_schedules_search` on `schedules(route_id, departure_time, status)`
- `idx_bookings_user` on `bookings(user_id, booking_date DESC)`

---

## 🧪 Automated Testing
Run the complete automated end-to-end integration test:
```bash
npm test
```
Verifies: User Signup ➔ Login ➔ Bus Search ➔ Multi-Seat Booking (ACID) ➔ Double-Booking Prevention Check ➔ Ticket Cancellation & Refund calculation.
