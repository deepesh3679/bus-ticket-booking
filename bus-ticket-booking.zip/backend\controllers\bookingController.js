const crypto = require('crypto');
const db = require('../config/db');

// Helper to generate a collision-free PNR
function generatePNR() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let pnr = 'PNR-';
  for (let i = 0; i < 6; i++) {
    pnr += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return pnr;
}

// -------------------------------------------------------------------------
// 1. CREATE BOOKING (SQL TRANSACTION)
// Guarantees ACID properties: Atomicity, Consistency, Isolation, Durability
// -------------------------------------------------------------------------
const createBooking = (req, res, next) => {
  try {
    const userId = req.user.id;
    const { schedule_id, passengers, payment_method = 'MOCK_UPI' } = req.body;

    if (!schedule_id || !Array.isArray(passengers) || passengers.length === 0) {
      return res.status(400).json({ error: 'Schedule ID and at least one passenger are required.' });
    }

    // Validate each passenger entry
    for (const p of passengers) {
      if (!p.seat_number || !p.passenger_name || !p.passenger_age) {
        return res.status(400).json({ error: 'Each passenger must have seat_number, passenger_name, and passenger_age.' });
      }
      if (isNaN(p.passenger_age) || Number(p.passenger_age) <= 0 || Number(p.passenger_age) > 120) {
        return res.status(400).json({ error: `Invalid age for passenger ${p.passenger_name}.` });
      }
    }

    // Check for duplicate seats within the same request
    const requestedSeatNumbers = passengers.map(p => p.seat_number.toString());
    const uniqueSeats = new Set(requestedSeatNumbers);
    if (uniqueSeats.size !== requestedSeatNumbers.length) {
      return res.status(400).json({ error: 'Duplicate seat numbers detected in the booking request.' });
    }

    // Execute SQLite Transaction
    const executeBookingTransaction = db.transaction(() => {
      // Step A: Check if schedule exists and is valid
      const schedule = db.prepare(`
        SELECT s.*, b.total_seats, b.bus_name, b.bus_number, r.source, r.destination
        FROM schedules s
        JOIN buses b ON s.bus_id = b.id
        JOIN routes r ON s.route_id = r.id
        WHERE s.id = ?
      `).get(schedule_id);

      if (!schedule) {
        throw new Error('Scheduled bus not found.');
      }

      if (schedule.status !== 'scheduled') {
        throw new Error(`Bus schedule is currently ${schedule.status} and cannot be booked.`);
      }

      // Step B: Verify if departure has already passed
      const depDate = new Date(schedule.departure_time);
      if (depDate <= new Date()) {
        throw new Error('Cannot book tickets for a bus that has already departed.');
      }

      // Step C: Verify seat availability for each seat
      const checkSeatStmt = db.prepare(`
        SELECT id FROM booking_passengers 
        WHERE schedule_id = ? AND seat_number = ? AND status = 'CONFIRMED'
      `);

      for (const seatNum of requestedSeatNumbers) {
        const existing = checkSeatStmt.get(schedule_id, seatNum);
        if (existing) {
          throw new Error(`Seat ${seatNum} is already booked by another passenger. Please select another seat.`);
        }
      }

      // Step D: Calculate total fare
      const totalFare = schedule.fare * passengers.length;

      // Step E: Create Booking Record with unique PNR
      let pnr = generatePNR();
      // Ensure PNR uniqueness
      while (db.prepare('SELECT id FROM bookings WHERE pnr = ?').get(pnr)) {
        pnr = generatePNR();
      }

      const insertBookingStmt = db.prepare(`
        INSERT INTO bookings (pnr, user_id, schedule_id, total_fare, status)
        VALUES (?, ?, ?, ?, 'CONFIRMED')
      `);
      const bookingResult = insertBookingStmt.run(pnr, userId, schedule_id, totalFare);
      const bookingId = bookingResult.lastInsertRowid;

      // Step F: Insert Passenger details & reserve seats
      // (idx_unique_active_seat SQLite unique partial index provides atomic concurrency defense)
      const insertPassengerStmt = db.prepare(`
        INSERT INTO booking_passengers 
        (booking_id, schedule_id, seat_number, passenger_name, passenger_age, passenger_gender, status)
        VALUES (?, ?, ?, ?, ?, ?, 'CONFIRMED')
      `);

      for (const p of passengers) {
        insertPassengerStmt.run(
          bookingId,
          schedule_id,
          p.seat_number.toString(),
          p.passenger_name.trim(),
          Number(p.passenger_age),
          p.passenger_gender || 'Other'
        );
      }

      // Step G: Generate Mock Payment Record
      const txnId = 'TXN-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7).toUpperCase();
      const insertPaymentStmt = db.prepare(`
        INSERT INTO payments (booking_id, amount, payment_method, transaction_id, status)
        VALUES (?, ?, ?, ?, 'SUCCESS')
      `);
      insertPaymentStmt.run(bookingId, totalFare, payment_method, txnId);

      return {
        bookingId,
        pnr,
        totalFare,
        txnId,
        schedule
      };
    });

    const result = executeBookingTransaction();

    res.status(201).json({
      message: 'Booking confirmed successfully!',
      booking: {
        id: result.bookingId,
        pnr: result.pnr,
        total_fare: result.totalFare,
        transaction_id: result.txnId,
        bus_name: result.schedule.bus_name,
        source: result.schedule.source,
        destination: result.schedule.destination,
        departure_time: result.schedule.departure_time,
        passenger_count: passengers.length,
        seats: requestedSeatNumbers
      }
    });

  } catch (error) {
    if (error.message.includes('UNIQUE constraint failed') || error.message.includes('already booked')) {
      return res.status(409).json({ error: error.message });
    }
    next(error);
  }
};

// -------------------------------------------------------------------------
// 2. GET USER'S BOOKINGS (MY BOOKINGS)
// -------------------------------------------------------------------------
const getUserBookings = (req, res, next) => {
  try {
    const userId = req.user.id;

    const bookings = db.prepare(`
      SELECT 
        b.id,
        b.pnr,
        b.total_fare,
        b.status AS booking_status,
        b.booking_date,
        s.id AS schedule_id,
        s.departure_time,
        s.arrival_time,
        s.fare AS per_seat_fare,
        bus.bus_name,
        bus.bus_number,
        bus.bus_type,
        r.source,
        r.destination,
        r.estimated_duration,
        p.transaction_id,
        p.status AS payment_status,
        p.refund_amount
      FROM bookings b
      JOIN schedules s ON b.schedule_id = s.id
      JOIN buses bus ON s.bus_id = bus.id
      JOIN routes r ON s.route_id = r.id
      LEFT JOIN payments p ON p.booking_id = b.id
      WHERE b.user_id = ?
      ORDER BY b.booking_date DESC
    `).all(userId);

    // Fetch passengers for each booking
    const getPassengersStmt = db.prepare(`
      SELECT seat_number, passenger_name, passenger_age, passenger_gender, status
      FROM booking_passengers
      WHERE booking_id = ?
    `);

    const detailedBookings = bookings.map(b => {
      const passengers = getPassengersStmt.all(b.id);
      
      // Calculate eligibility for cancellation & estimated refund
      const now = new Date();
      const depDate = new Date(b.departure_time);
      const hoursUntilDeparture = (depDate - now) / (1000 * 60 * 60);

      let refundPercent = 0;
      let canCancel = b.booking_status === 'CONFIRMED' && hoursUntilDeparture > 0;

      if (hoursUntilDeparture > 24) {
        refundPercent = 100;
      } else if (hoursUntilDeparture > 0) {
        refundPercent = 50;
      } else {
        refundPercent = 0;
      }

      return {
        ...b,
        passengers,
        canCancel,
        hoursUntilDeparture: hoursUntilDeparture.toFixed(1),
        eligibleRefundPercent: refundPercent,
        estimatedRefund: canCancel ? (b.total_fare * (refundPercent / 100)).toFixed(2) : '0.00'
      };
    });

    res.json({ bookings: detailedBookings });
  } catch (error) {
    next(error);
  }
};

// -------------------------------------------------------------------------
// 3. GET SINGLE BOOKING BY PNR
// -------------------------------------------------------------------------
const getBookingByPNR = (req, res, next) => {
  try {
    const { pnr } = req.params;

    const booking = db.prepare(`
      SELECT 
        b.id,
        b.pnr,
        b.user_id,
        b.total_fare,
        b.status AS booking_status,
        b.booking_date,
        u.name AS booked_by_name,
        u.email AS booked_by_email,
        u.phone AS booked_by_phone,
        s.departure_time,
        s.arrival_time,
        bus.bus_name,
        bus.bus_number,
        bus.bus_type,
        r.source,
        r.destination,
        r.distance_km,
        p.transaction_id,
        p.status AS payment_status,
        p.refund_amount
      FROM bookings b
      JOIN users u ON b.user_id = u.id
      JOIN schedules s ON b.schedule_id = s.id
      JOIN buses bus ON s.bus_id = bus.id
      JOIN routes r ON s.route_id = r.id
      LEFT JOIN payments p ON p.booking_id = b.id
      WHERE b.pnr = ?
    `).get(pnr.trim().toUpperCase());

    if (!booking) {
      return res.status(404).json({ error: 'No booking found with this PNR.' });
    }

    // Access control: only owner or admin can view
    if (req.user.role !== 'admin' && req.user.id !== booking.user_id) {
      return res.status(403).json({ error: 'Access denied to this booking.' });
    }

    const passengers = db.prepare(`
      SELECT seat_number, passenger_name, passenger_age, passenger_gender, status
      FROM booking_passengers
      WHERE booking_id = ?
    `).all(booking.id);

    res.json({ booking: { ...booking, passengers } });
  } catch (error) {
    next(error);
  }
};

// -------------------------------------------------------------------------
// 4. CANCEL BOOKING (SQL TRANSACTION + REFUND POLICY)
// - > 24 hours before departure: 100% refund
// - 0 to 24 hours before departure: 50% refund
// - After departure: 0% refund
// -------------------------------------------------------------------------
const cancelBooking = (req, res, next) => {
  try {
    const { bookingId } = req.params;
    const userId = req.user.id;
    const isAdmin = req.user.role === 'admin';

    const executeCancellation = db.transaction(() => {
      // 1. Fetch booking with schedule
      const booking = db.prepare(`
        SELECT b.*, s.departure_time
        FROM bookings b
        JOIN schedules s ON b.schedule_id = s.id
        WHERE b.id = ?
      `).get(bookingId);

      if (!booking) {
        throw new Error('Booking not found.');
      }

      // Check ownership
      if (!isAdmin && booking.user_id !== userId) {
        throw new Error('Unauthorized to cancel this booking.');
      }

      if (booking.status === 'CANCELLED') {
        throw new Error('This booking has already been cancelled.');
      }

      // 2. Refund calculation based on departure time
      const now = new Date();
      const depDate = new Date(booking.departure_time);
      const hoursUntilDeparture = (depDate - now) / (1000 * 60 * 60);

      let refundPercentage = 0;
      if (hoursUntilDeparture > 24) {
        refundPercentage = 100;
      } else if (hoursUntilDeparture > 0) {
        refundPercentage = 50;
      } else {
        refundPercentage = 0;
      }

      const refundAmount = (booking.total_fare * refundPercentage) / 100;

      // 3. Update booking status
      db.prepare(`UPDATE bookings SET status = 'CANCELLED' WHERE id = ?`).run(bookingId);

      // 4. Update passenger records to CANCELLED
      // This releases the partial unique index constraint on (schedule_id, seat_number)!
      db.prepare(`UPDATE booking_passengers SET status = 'CANCELLED' WHERE booking_id = ?`).run(bookingId);

      // 5. Update payment record
      const paymentStatus = refundPercentage === 100 ? 'REFUNDED' : (refundPercentage === 50 ? 'PARTIAL_REFUND' : 'SUCCESS');
      db.prepare(`
        UPDATE payments 
        SET status = ?, refund_amount = ? 
        WHERE booking_id = ?
      `).run(paymentStatus, refundAmount, bookingId);

      return {
        bookingId,
        pnr: booking.pnr,
        refundPercentage,
        refundAmount,
        hoursUntilDeparture: hoursUntilDeparture.toFixed(1)
      };
    });

    const result = executeCancellation();

    res.json({
      message: 'Booking cancelled successfully. Seats have been released.',
      cancellation: {
        booking_id: result.bookingId,
        pnr: result.pnr,
        refund_percentage: `${result.refundPercentage}%`,
        refund_amount: result.refundAmount,
        hours_before_departure: result.hoursUntilDeparture
      }
    });
  } catch (error) {
    if (error.message.includes('already been cancelled') || error.message.includes('Unauthorized')) {
      return res.status(400).json({ error: error.message });
    }
    next(error);
  }
};

module.exports = {
  createBooking,
  getUserBookings,
  getBookingByPNR,
  cancelBooking
};
