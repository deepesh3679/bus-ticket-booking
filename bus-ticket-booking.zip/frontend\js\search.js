// Bus Search and Listing Logic
document.addEventListener('DOMContentLoaded', async () => {
  await loadCities();
  initDateInput();

  // If search parameters are in URL, automatically run search
  const params = new URLSearchParams(window.location.search);
  const source = params.get('source');
  const destination = params.get('destination');
  const date = params.get('date');

  if (source && destination) {
    const srcInput = document.getElementById('search-source');
    const dstInput = document.getElementById('search-destination');
    const dateInput = document.getElementById('search-date');

    if (srcInput) srcInput.value = source;
    if (dstInput) dstInput.value = destination;
    if (dateInput && date) dateInput.value = date;

    executeSearch(source, destination, date);
  }

  // Handle Search Form Submit
  const searchForm = document.getElementById('bus-search-form');
  if (searchForm) {
    searchForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const s = document.getElementById('search-source').value.trim();
      const d = document.getElementById('search-destination').value.trim();
      const dt = document.getElementById('search-date').value;

      if (!s || !d) {
        showToast('Please select both source and destination.', 'error');
        return;
      }
      if (s.toLowerCase() === d.toLowerCase()) {
        showToast('Source and destination cannot be the same city.', 'error');
        return;
      }

      executeSearch(s, d, dt);
    });
  }

  // Swap button
  const swapBtn = document.getElementById('swap-cities-btn');
  if (swapBtn) {
    swapBtn.addEventListener('click', () => {
      const srcInput = document.getElementById('search-source');
      const dstInput = document.getElementById('search-destination');
      const temp = srcInput.value;
      srcInput.value = dstInput.value;
      dstInput.value = temp;
    });
  }
});

// Load distinct cities into datalists
async function loadCities() {
  try {
    const res = await API.get('/api/buses/cities');
    const sourceList = document.getElementById('source-cities');
    const destList = document.getElementById('dest-cities');

    if (res.cities && (sourceList || destList)) {
      const optionsHtml = res.cities.map(c => `<option value="${c}">${c}</option>`).join('');
      if (sourceList) sourceList.innerHTML = optionsHtml;
      if (destList) destList.innerHTML = optionsHtml;
    }
  } catch (err) {
    console.error('Failed to load cities:', err);
  }
}

// Set minimum date to today
function initDateInput() {
  const dateInput = document.getElementById('search-date');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.min = today;
    if (!dateInput.value) {
      dateInput.value = today;
    }
  }
}

// Execute search query
async function executeSearch(source, destination, date) {
  const container = document.getElementById('search-results-container');
  if (!container) return;

  container.innerHTML = `
    <div style="text-align: center; padding: 3rem;">
      <p style="font-size: 1.1rem; color: var(--gray-500);">🔍 Searching scheduled buses from <strong>${source}</strong> to <strong>${destination}</strong>...</p>
    </div>
  `;

  try {
    let url = `/api/buses/search?source=${encodeURIComponent(source)}&destination=${encodeURIComponent(destination)}`;
    if (date) url += `&date=${encodeURIComponent(date)}`;

    const res = await API.get(url);

    if (!res.schedules || res.schedules.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; background: var(--white); padding: 3.5rem; border-radius: var(--radius-lg); border: 1px solid var(--gray-200);">
          <div style="font-size: 3rem; margin-bottom: 0.5rem;">🚌💨</div>
          <h3 style="font-size: 1.3rem; margin-bottom: 0.5rem; color: var(--gray-800);">No buses found for this route</h3>
          <p style="color: var(--gray-500); max-width: 480px; margin: 0 auto 1.5rem;">
            No scheduled departures found from <strong>${source}</strong> to <strong>${destination}</strong> on ${date ? formatDate(date) : 'this date'}.
          </p>
          <p style="font-size: 0.9rem; color: var(--gray-400);">Try searching demo routes: <em>Mumbai ➔ Pune</em>, <em>Bangalore ➔ Hyderabad</em>, or <em>Delhi ➔ Jaipur</em></p>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div style="margin-bottom: 1.25rem; display: flex; justify-content: space-between; align-items: center;">
        <h2 style="font-size: 1.25rem; color: var(--gray-900);">Available Buses (${res.schedules.length})</h2>
        <span style="font-size: 0.9rem; color: var(--gray-500);">${source} ➔ ${destination}</span>
      </div>
      <div class="bus-list">
        ${res.schedules.map(renderBusCard).join('')}
      </div>
    `;

  } catch (err) {
    container.innerHTML = `
      <div style="background: var(--danger-light); color: var(--danger); padding: 1.5rem; border-radius: var(--radius-md); text-align: center;">
        ${err.message || 'Error fetching bus schedules.'}
      </div>
    `;
  }
}

// Render a single bus card
function renderBusCard(s) {
  const depTime = formatDateTime(s.departure_time);
  const arrTime = formatDateTime(s.arrival_time);
  const isAvailable = s.available_seats > 0;

  return `
    <div class="bus-card">
      <div class="bus-info">
        <h3>${s.bus_name}</h3>
        <div class="bus-meta">
          <span class="badge badge-info">${s.bus_type}</span>
          <span>Reg: ${s.bus_number}</span>
        </div>
      </div>

      <div class="bus-timeline">
        <div class="time-box">
          <div class="time">${depTime.split(',')[1] || depTime}</div>
          <div class="city">${s.source}</div>
          <div style="font-size: 0.75rem; color: var(--gray-400);">${depTime.split(',')[0]}</div>
        </div>

        <div class="duration-line">
          <div class="duration">⏱️ ${s.estimated_duration}</div>
          <div class="line"></div>
          <div style="font-size: 0.7rem; color: var(--gray-400); margin-top: 0.2rem;">${s.distance_km} km</div>
        </div>

        <div class="time-box">
          <div class="time">${arrTime.split(',')[1] || arrTime}</div>
          <div class="city">${s.destination}</div>
          <div style="font-size: 0.75rem; color: var(--gray-400);">${arrTime.split(',')[0]}</div>
        </div>
      </div>

      <div class="bus-pricing">
        <div class="price">${formatCurrency(s.fare)}</div>
        <div class="seats-left ${s.available_seats <= 5 ? 'seats-low' : 'seats-available'}">
          ${isAvailable ? `💺 ${s.available_seats} seats left` : '❌ Sold Out'}
        </div>
      </div>

      <div>
        ${isAvailable ? `
          <a href="seat-selection.html?scheduleId=${s.schedule_id}" class="btn btn-primary">
            Select Seats
          </a>
        ` : `
          <button class="btn btn-secondary" disabled>Sold Out</button>
        `}
      </div>
    </div>
  `;
}
