# DBMS Theoretical Concepts & Viva Examination Guide
## Bus Ticket Booking System

This document is prepared specifically for college laboratory examinations, external viva-voce, and backend technical reviews.

---

## 1. Relational Database Normalization (3NF)

A relational schema is in **Third Normal Form (3NF)** if and only if:
1. It is in **First Normal Form (1NF)**: All attributes contain atomic (indivisible) values, and there are no repeating groups.
2. It is in **Second Normal Form (2NF)**: It is in 1NF and every non-prime attribute is fully functionally dependent on the primary key (no partial dependencies).
3. It is in **Third Normal Form (3NF)**: It is in 2NF and no non-prime attribute is transitively dependent on the primary key (i.e., $X \to Y$ and $Y \to Z$ where $Z$ is non-prime is eliminated).

### 3NF Proof Table by Table

| Table | Primary Key | Functional Dependencies | Transitive / Partial Dependencies Removed |
| :--- | :--- | :--- | :--- |
| `users` | `id` | `id` $\to$ `name, email, password_hash, phone, role, created_at` | Email is distinct and candidate key; role is an atomic string constrained by `CHECK`. |
| `buses` | `id` | `id` $\to$ `bus_number, bus_name, bus_type, total_seats` | Bus physical attributes are isolated from route and trip schedules. |
| `routes` | `id` | `id` $\to$ `source, destination, distance_km, estimated_duration` | Geographical route specs are isolated from buses and trip dates. |
| `schedules` | `id` | `id` $\to$ `bus_id, route_id, departure_time, arrival_time, fare, status` | Connects a bus to a route at a specific time with a trip fare. |
| `seats` | `id` | `id` $\to$ `bus_id, seat_number, seat_type, deck` | Static layout blueprint of each bus. |
| `bookings` | `id` | `id` $\to$ `pnr, user_id, schedule_id, total_fare, status, booking_date` | Header entity for a customer transaction. |
| `booking_passengers` | `id` | `id` $\to$ `booking_id, schedule_id, seat_number, passenger_name, passenger_age, passenger_gender, status` | Normalized 1:N relationship so multiple passengers per ticket do not create repeating arrays. |
| `payments` | `id` | `id` $\to$ `booking_id, amount, payment_method, transaction_id, status, refund_amount` | Financial transaction audit trail isolated from operational booking state. |

---

## 2. ACID Properties & Relational Transactions

In high-concurrency booking systems, seat allocation must adhere to strict **ACID** properties:

- **Atomicity ("All or Nothing")**:
  When a user books 3 seats:
  1. The availability of all 3 seats is checked.
  2. The booking header is created.
  3. All 3 passenger seat records are inserted.
  4. The payment record is created.
  If the 3rd seat fails or is reserved by someone else concurrently, the entire operation **rolls back immediately**. No orphan booking records or unallocated payments can ever exist.

- **Consistency**:
  Integrity constraints (Foreign Keys `REFERENCES`, `CHECK(fare >= 0)`, `CHECK(arrival_time > departure_time)`) are strictly preserved before and after each state change.

- **Isolation**:
  SQLite executes transactions in `IMMEDIATE` mode with `WAL` (Write-Ahead Logging). This prevents "dirty reads" ($G_1$) and non-repeatable reads ($G_2$).

- **Durability**:
  Once committed, the transaction state is permanently appended to the SQLite Write-Ahead Log (`.sqlite-wal`) and synchronized to disk.

---

## 3. Concurrency Control & Double-Booking Prevention

A common bug in beginner booking systems is the **Race Condition**: two users opening seat 14 at the same time and both clicking "Book".

### How Our System Solves This at the Engine Level:
1. **SQLite Partial Unique Index**:
   ```sql
   CREATE UNIQUE INDEX idx_unique_active_seat 
   ON booking_passengers(schedule_id, seat_number) 
   WHERE status = 'CONFIRMED';
   ```
2. **Immediate Lock Transaction**:
   ```javascript
   const executeBookingTransaction = db.transaction(() => {
     // Check availability
     // Insert booking
     // Insert passengers (violating the partial unique index throws an instant SQLITE_CONSTRAINT error)
     // Insert payment
   });
   ```
3. **Seat Release Mechanism**:
   When a booking is cancelled, the passenger records are updated to `status = 'CANCELLED'`. Because the unique index has the predicate `WHERE status = 'CONFIRMED'`, the cancelled seat is immediately freed up for other users!

---

## 4. Indexing & B-Tree Performance Optimization

Without database indexes, querying bus routes or user bookings requires a **Full Table Scan ($O(N)$)**. SQLite utilizes B-Tree index structures ($O(\log N)$):

1. **Route Search Index**:
   ```sql
   CREATE INDEX idx_routes_source_dest ON routes(source, destination);
   ```
   *Benefit*: Searches for `source = 'Mumbai' AND destination = 'Pune'` perform index lookups instead of scanning every route row.

2. **Schedule Search Index**:
   ```sql
   CREATE INDEX idx_schedules_search ON schedules(route_id, departure_time, status);
   ```
   *Benefit*: Speeds up filtering available departures for a specific route on a specific date.

3. **User Bookings Index**:
   ```sql
   CREATE INDEX idx_bookings_user ON bookings(user_id, booking_date DESC);
   ```
   *Benefit*: Enables instant retrieval of a customer's past and upcoming travel history sorted chronologically.

---

## 5. College Viva Questions & Model Answers

### Q1: Why did you separate `schedules` from `routes` and `buses`?
> **Answer**: To maintain 3NF and prevent data redundancy. A route (e.g. Mumbai to Pune, 150 km) is static geography. A bus is physical fleet inventory. Multiple buses can run on the same route at different departure times. Storing route info inside each trip schedule would cause update anomalies if the route distance or name changed.

### Q2: What is the purpose of the Write-Ahead Log (WAL) mode in SQLite?
> **Answer**: `PRAGMA journal_mode = WAL` enables concurrent readers and writers. In default rollback journal mode, writing locks the entire database. In WAL mode, changes are written to a separate WAL log, allowing read queries to proceed concurrently with high throughput.

### Q3: How is the refund calculated during cancellation?
> **Answer**:
> - Departure $> 24$ hours away: **100% Refund**.
> - Departure between $0$ and $24$ hours: **50% Refund**.
> - Departure $\le 0$ hours (bus has departed): **0% Refund (Non-refundable)**.
> All calculations occur inside an ACID transaction updating both the `bookings` status and the `payments` refund audit column.
