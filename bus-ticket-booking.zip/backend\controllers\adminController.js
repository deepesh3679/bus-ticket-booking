const db = require('../config/db');

// Helper to seed seats for a bus (e.g. 40 seats: 1 to 40 in 2x2 layout)
function createSeatsForBus(busId, totalSeats = 40) {
  const insertSeat = db.prepare(`
    INSERT OR IGNORE INTO seats (bus_id, seat_number, seat_type, deck)
    VALUES (?, ?, ?, 'lower')
  `);

  for (let i = 1; i <= totalSeats; i++) {
    // In a standard 2x2 layout:
    // Column 1 & 4 are window seats (i % 4 === 1 or i % 4 === 0)
    // Column 2 & 3 are aisle seats (i % 4 === 2 or i % 4 === 3)
    const mod = i % 4;
    const seatType = (mod === 1 || mod === 0) ? 'window' : 'aisle';
    insertSeat.run(busId, i.toString(), seatType);
  }
}

// -------------------------------------------------------------------------
// DASHBOARD STATS
// -------------------------------------------------------------------------
const getDashboardStats = (req, res, next) => {
  try {
    const totalUsers = db.prepare("SELECT COUNT(*) as count FROM users WHERE role = 'user'").get().count;
    const totalBuses = db.prepare("SELECT COUNT(*) as count FROM buses").get().count;
    const totalRoutes = db.prepare("SELECT COUNT(*) as count FROM routes").get().count;
    const totalSchedules = db.prepare("SELECT COUNT(*) as count FROM schedules").get().count;
    const totalBookings = db.prepare("SELECT COUNT(*) as count FROM bookings").get().count;
    const confirmedBookings = db.prepare("SELECT COUNT(*) as count FROM bookings WHERE status = 'CONFIRMED'").get().count;
    const cancelledBookings = db.prepare("SELECT COUNT(*) as count FROM bookings WHERE status = 'CANCELLED'").get().count;
    
    const revenueResult = db.prepare(`
      SELECT 
        COALESCE(SUM(b.total_fare), 0) AS gross_revenue,
        COALESCE(SUM(p.refund_amount), 0) AS total_refunded,
        (COALESCE(SUM(b.total_fare), 0) - COALESCE(SUM(p.refund_amount), 0)) AS net_revenue
      FROM bookings b
      LEFT JOIN payments p ON p.booking_id = b.id
    `).get();

    res.json({
      totalUsers,
      totalBuses,
      totalRoutes,
      totalSchedules,
      totalBookings,
      confirmedBookings,
      cancelledBookings,
      revenue: revenueResult
    });
  } catch (error) {
    next(error);
  }
};

// -------------------------------------------------------------------------
// BUS MANAGEMENT
// -------------------------------------------------------------------------
const getAllBuses = (req, res, next) => {
  try {
    const buses = db.prepare('SELECT * FROM buses ORDER BY id DESC').all();
    res.json({ buses });
  } catch (error) {
    next(error);
  }
};

const addBus = (req, res, next) => {
  try {
    const { bus_number, bus_name, bus_type, total_seats = 40 } = req.body;

    if (!bus_number || !bus_name || !bus_type) {
      return res.status(400).json({ error: 'bus_number, bus_name, and bus_type are required.' });
    }

    const seatsCount = Number(total_seats) || 40;

    const tx = db.transaction(() => {
      const insert = db.prepare(`
        INSERT INTO buses (bus_number, bus_name, bus_type, total_seats)
        VALUES (?, ?, ?, ?)
      `);
      const result = insert.run(bus_number.trim(), bus_name.trim(), bus_type.trim(), seatsCount);
      const busId = result.lastInsertRowid;

      // Automatically populate physical seats
      createSeatsForBus(busId, seatsCount);
      return busId;
    });

    const busId = tx();
    res.status(201).json({ message: 'Bus created successfully with seat blueprint.', busId });
  } catch (error) {
    next(error);
  }
};

const editBus = (req, res, next) => {
  try {
    const { id } = req.params;
    const { bus_name, bus_type } = req.body;

    if (!bus_name || !bus_type) {
      return res.status(400).json({ error: 'bus_name and bus_type are required.' });
    }

    const update = db.prepare(`
      UPDATE buses 
      SET bus_name = ?, bus_type = ?
      WHERE id = ?
    `);
    const result = update.run(bus_name.trim(), bus_type.trim(), id);

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Bus not found.' });
    }

    res.json({ message: 'Bus updated successfully.' });
  } catch (error) {
    next(error);
  }
};

const deleteBus = (req, res, next) => {
  try {
    const { id } = req.params;
    const del = db.prepare('DELETE FROM buses WHERE id = ?');
    const result = del.run(id);

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Bus not found.' });
    }

    res.json({ message: 'Bus and related schedules deleted successfully.' });
  } catch (error) {
    next(error);
  }
};

// -------------------------------------------------------------------------
// ROUTE MANAGEMENT
// -------------------------------------------------------------------------
const getAllRoutes = (req, res, next) => {
  try {
    const routes = db.prepare('SELECT * FROM routes ORDER BY source ASC, destination ASC').all();
    res.json({ routes });
  } catch (error) {
    next(error);
  }
};

const addRoute = (req, res, next) => {
  try {
    const { source, destination, distance_km, estimated_duration } = req.body;

    if (!source || !destination || !distance_km || !estimated_duration) {
      return res.status(400).json({ error: 'source, destination, distance_km, and estimated_duration are required.' });
    }

    const insert = db.prepare(`
      INSERT INTO routes (source, destination, distance_km, estimated_duration)
      VALUES (?, ?, ?, ?)
    `);
    const result = insert.run(
      source.trim(),
      destination.trim(),
      Number(distance_km),
      estimated_duration.trim()
    );

    res.status(201).json({ message: 'Route added successfully.', routeId: result.lastInsertRowid });
  } catch (error) {
    next(error);
  }
};

const editRoute = (req, res, next) => {
  try {
    const { id } = req.params;
    const { distance_km, estimated_duration } = req.body;

    if (!distance_km || !estimated_duration) {
      return res.status(400).json({ error: 'distance_km and estimated_duration are required.' });
    }

    const update = db.prepare(`
      UPDATE routes 
      SET distance_km = ?, estimated_duration = ?
      WHERE id = ?
    `);
    const result = update.run(Number(distance_km), estimated_duration.trim(), id);

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Route not found.' });
    }

    res.json({ message: 'Route updated successfully.' });
  } catch (error) {
    next(error);
  }
};

const deleteRoute = (req, res, next) => {
  try {
    const { id } = req.params;
    const del = db.prepare('DELETE FROM routes WHERE id = ?');
    const result = del.run(id);

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Route not found.' });
    }

    res.json({ message: 'Route deleted successfully.' });
  } catch (error) {
    next(error);
  }
};

// -------------------------------------------------------------------------
// SCHEDULE MANAGEMENT
// -------------------------------------------------------------------------
const getAllSchedules = (req, res, next) => {
  try {
    const schedules = db.prepare(`
      SELECT 
        s.*,
        b.bus_number,
        b.bus_name,
        b.bus_type,
        b.total_seats,
        r.source,
        r.destination,
        r.estimated_duration,
        (
          SELECT COUNT(bp.id)
          FROM booking_passengers bp
          WHERE bp.schedule_id = s.id AND bp.status = 'CONFIRMED'
        ) AS booked_seats
      FROM schedules s
      JOIN buses b ON s.bus_id = b.id
      JOIN routes r ON s.route_id = r.id
      ORDER BY s.departure_time DESC
    `).all();

    res.json({ schedules });
  } catch (error) {
    next(error);
  }
};

const addSchedule = (req, res, next) => {
  try {
    const { bus_id, route_id, departure_time, arrival_time, fare } = req.body;

    if (!bus_id || !route_id || !departure_time || !arrival_time || fare === undefined) {
      return res.status(400).json({ error: 'bus_id, route_id, departure_time, arrival_time, and fare are required.' });
    }

    if (new Date(arrival_time) <= new Date(departure_time)) {
      return res.status(400).json({ error: 'Arrival time must be after departure time.' });
    }

    const insert = db.prepare(`
      INSERT INTO schedules (bus_id, route_id, departure_time, arrival_time, fare, status)
      VALUES (?, ?, ?, ?, ?, 'scheduled')
    `);
    const result = insert.run(bus_id, route_id, departure_time, arrival_time, Number(fare));

    res.status(201).json({ message: 'Schedule added successfully.', scheduleId: result.lastInsertRowid });
  } catch (error) {
    next(error);
  }
};

const editSchedule = (req, res, next) => {
  try {
    const { id } = req.params;
    const { departure_time, arrival_time, fare, status } = req.body;

    if (!departure_time || !arrival_time || fare === undefined || !status) {
      return res.status(400).json({ error: 'departure_time, arrival_time, fare, and status are required.' });
    }

    if (new Date(arrival_time) <= new Date(departure_time)) {
      return res.status(400).json({ error: 'Arrival time must be after departure time.' });
    }

    const update = db.prepare(`
      UPDATE schedules 
      SET departure_time = ?, arrival_time = ?, fare = ?, status = ?
      WHERE id = ?
    `);
    const result = update.run(departure_time, arrival_time, Number(fare), status, id);

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Schedule not found.' });
    }

    res.json({ message: 'Schedule updated successfully.' });
  } catch (error) {
    next(error);
  }
};

const deleteSchedule = (req, res, next) => {
  try {
    const { id } = req.params;
    const del = db.prepare('DELETE FROM schedules WHERE id = ?');
    const result = del.run(id);

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Schedule not found.' });
    }

    res.json({ message: 'Schedule deleted successfully.' });
  } catch (error) {
    next(error);
  }
};

// -------------------------------------------------------------------------
// ALL BOOKINGS MANAGEMENT
// -------------------------------------------------------------------------
const getAllBookings = (req, res, next) => {
  try {
    const bookings = db.prepare(`
      SELECT 
        b.id,
        b.pnr,
        b.total_fare,
        b.status AS booking_status,
        b.booking_date,
        u.name AS user_name,
        u.email AS user_email,
        u.phone AS user_phone,
        bus.bus_name,
        bus.bus_number,
        r.source,
        r.destination,
        s.departure_time,
        p.transaction_id,
        p.status AS payment_status,
        p.refund_amount
      FROM bookings b
      JOIN users u ON b.user_id = u.id
      JOIN schedules s ON b.schedule_id = s.id
      JOIN buses bus ON s.bus_id = bus.id
      JOIN routes r ON s.route_id = r.id
      LEFT JOIN payments p ON p.booking_id = b.id
      ORDER BY b.booking_date DESC
    `).all();

    const getPassengersStmt = db.prepare(`
      SELECT seat_number, passenger_name, passenger_age, passenger_gender, status
      FROM booking_passengers
      WHERE booking_id = ?
    `);

    const result = bookings.map(b => ({
      ...b,
      passengers: getPassengersStmt.all(b.id)
    }));

    res.json({ bookings: result });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getDashboardStats,
  getAllBuses,
  addBus,
  editBus,
  deleteBus,
  getAllRoutes,
  addRoute,
  editRoute,
  deleteRoute,
  getAllSchedules,
  addSchedule,
  editSchedule,
  deleteSchedule,
  getAllBookings
};
