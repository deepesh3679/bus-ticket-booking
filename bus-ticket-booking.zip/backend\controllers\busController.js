const db = require('../config/db');

// Get all distinct cities available in routes
const getCities = (req, res, next) => {
  try {
    const sources = db.prepare('SELECT DISTINCT source as city FROM routes ORDER BY source ASC').all();
    const destinations = db.prepare('SELECT DISTINCT destination as city FROM routes ORDER BY destination ASC').all();
    
    // Merge unique cities
    const citySet = new Set();
    sources.forEach(s => citySet.add(s.city));
    destinations.forEach(d => citySet.add(d.city));

    res.json({
      cities: Array.from(citySet).sort(),
      sources: sources.map(s => s.city),
      destinations: destinations.map(d => d.city)
    });
  } catch (error) {
    next(error);
  }
};

// Search buses by source, destination, and departure date
const searchBuses = (req, res, next) => {
  try {
    const { source, destination, date } = req.query;

    if (!source || !destination) {
      return res.status(400).json({ error: 'Source and destination cities are required.' });
    }

    let query = `
      SELECT 
        s.id AS schedule_id,
        s.departure_time,
        s.arrival_time,
        s.fare,
        s.status AS schedule_status,
        b.id AS bus_id,
        b.bus_number,
        b.bus_name,
        b.bus_type,
        b.total_seats,
        r.id AS route_id,
        r.source,
        r.destination,
        r.distance_km,
        r.estimated_duration,
        (
          b.total_seats - (
            SELECT COUNT(bp.id)
            FROM booking_passengers bp
            WHERE bp.schedule_id = s.id AND bp.status = 'CONFIRMED'
          )
        ) AS available_seats
      FROM schedules s
      JOIN buses b ON s.bus_id = b.id
      JOIN routes r ON s.route_id = r.id
      WHERE LOWER(r.source) = LOWER(?)
        AND LOWER(r.destination) = LOWER(?)
        AND s.status = 'scheduled'
    `;

    const params = [source.trim(), destination.trim()];

    if (date) {
      query += ` AND date(s.departure_time) = date(?)`;
      params.push(date.trim());
    }

    query += ` ORDER BY s.departure_time ASC`;

    const schedules = db.prepare(query).all(...params);

    res.json({
      count: schedules.length,
      search: { source, destination, date },
      schedules
    });
  } catch (error) {
    next(error);
  }
};

// Get single schedule details and full visual seat layout with booked status
const getScheduleSeats = (req, res, next) => {
  try {
    const { scheduleId } = req.params;

    // 1. Fetch schedule info
    const scheduleQuery = `
      SELECT 
        s.id AS schedule_id,
        s.departure_time,
        s.arrival_time,
        s.fare,
        s.status,
        b.id AS bus_id,
        b.bus_number,
        b.bus_name,
        b.bus_type,
        b.total_seats,
        r.source,
        r.destination,
        r.estimated_duration,
        r.distance_km
      FROM schedules s
      JOIN buses b ON s.bus_id = b.id
      JOIN routes r ON s.route_id = r.id
      WHERE s.id = ?
    `;
    const schedule = db.prepare(scheduleQuery).get(scheduleId);

    if (!schedule) {
      return res.status(404).json({ error: 'Bus schedule not found.' });
    }

    // 2. Fetch all physical seats for this bus
    const seats = db.prepare(`
      SELECT seat_number, seat_type, deck
      FROM seats
      WHERE bus_id = ?
      ORDER BY CAST(seat_number AS INTEGER) ASC
    `).all(schedule.bus_id);

    // 3. Fetch currently booked seat numbers for this schedule
    const bookedPassengers = db.prepare(`
      SELECT seat_number
      FROM booking_passengers
      WHERE schedule_id = ? AND status = 'CONFIRMED'
    `).all(scheduleId);

    const bookedSeatNumbers = bookedPassengers.map(bp => bp.seat_number.toString());

    // 4. Mark seat status (available vs booked)
    const formattedSeats = seats.map(s => ({
      seat_number: s.seat_number,
      seat_type: s.seat_type,
      deck: s.deck,
      is_booked: bookedSeatNumbers.includes(s.seat_number.toString())
    }));

    res.json({
      schedule,
      seats: formattedSeats,
      total_seats: schedule.total_seats,
      available_seats: schedule.total_seats - bookedSeatNumbers.length,
      booked_count: bookedSeatNumbers.length
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getCities,
  searchBuses,
  getScheduleSeats
};
