const fs = require('fs');
const path = require('path');
require('dotenv').config();

const dbPath = path.resolve(__dirname, '../../', process.env.DB_FILE || 'backend/db/database.sqlite');

// Ensure database directory exists
const dbDir = path.dirname(dbPath);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

let db;

// 1. Try loading better-sqlite3
try {
  const Database = require('better-sqlite3');
  db = new Database(dbPath);
  console.log('📦 SQLite initialized via better-sqlite3');
} catch (err) {
  // 2. Seamless fallback to Node.js native built-in node:sqlite (DatabaseSync)
  // Available natively in Node v22.5.0+ and Node v24+
  console.log('⚡ Using Node.js native SQLite engine (DatabaseSync)');
  const { DatabaseSync } = require('node:sqlite');
  const nativeDb = new DatabaseSync(dbPath);

  // Wrap with better-sqlite3 compatible API
  db = {
    _native: nativeDb,
    pragma(pragmaStr) {
      try {
        return nativeDb.exec(`PRAGMA ${pragmaStr};`);
      } catch (e) {
        console.warn(`Pragma ${pragmaStr} warning:`, e.message);
      }
    },
    exec(sql) {
      return nativeDb.exec(sql);
    },
    prepare(sql) {
      const stmt = nativeDb.prepare(sql);
      return {
        run: (...params) => {
          const args = (params.length === 1 && Array.isArray(params[0])) ? params[0] : params;
          const res = stmt.run(...args);
          return {
            changes: Number(res.changes),
            lastInsertRowid: Number(res.lastInsertRowid)
          };
        },
        get: (...params) => {
          const args = (params.length === 1 && Array.isArray(params[0])) ? params[0] : params;
          return stmt.get(...args);
        },
        all: (...params) => {
          const args = (params.length === 1 && Array.isArray(params[0])) ? params[0] : params;
          return stmt.all(...args);
        }
      };
    },
    transaction(fn) {
      return (...args) => {
        nativeDb.exec('BEGIN IMMEDIATE;');
        try {
          const res = fn(...args);
          nativeDb.exec('COMMIT;');
          return res;
        } catch (error) {
          nativeDb.exec('ROLLBACK;');
          throw error;
        }
      };
    }
  };
}

// Enable foreign keys and WAL mode
db.pragma('foreign_keys = ON');
db.pragma('journal_mode = WAL');

// Execute initial schema
function initDatabase() {
  const schemaPath = path.resolve(__dirname, '../db/schema.sql');
  if (fs.existsSync(schemaPath)) {
    const schemaSql = fs.readFileSync(schemaPath, 'utf8');
    db.exec(schemaSql);
  }
}

initDatabase();

module.exports = db;
