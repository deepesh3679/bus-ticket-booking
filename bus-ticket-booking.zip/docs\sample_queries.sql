-- ====================================================================
-- Bus Ticket Booking System - Sample Analytical & Operational Queries
-- Designed for College DBMS Project Viva & Technical Demonstrations
-- ====================================================================

-- --------------------------------------------------------------------
-- QUERY 1: Active Bus Search with Dynamic Seat Availability Calculation
-- Concepts: INNER JOIN, Correlated Subquery, Date Filtering, Aggregate COUNT
-- Purpose: Finds available buses between two cities on a specific travel date
--          along with the real-time number of remaining available seats.
-- --------------------------------------------------------------------
SELECT 
    s.id AS schedule_id,
    b.bus_number,
    b.bus_name,
    b.bus_type,
    r.source,
    r.destination,
    s.departure_time,
    s.arrival_time,
    r.estimated_duration,
    s.fare AS ticket_fare,
    b.total_seats,
    (
        b.total_seats - (
            SELECT COUNT(bp.id)
            FROM booking_passengers bp
            WHERE bp.schedule_id = s.id 
              AND bp.status = 'CONFIRMED'
        )
    ) AS available_seats
FROM schedules s
JOIN buses b ON s.bus_id = b.id
JOIN routes r ON s.route_id = r.id
WHERE LOWER(r.source) = LOWER('Mumbai')
  AND LOWER(r.destination) = LOWER('Pune')
  AND s.status = 'scheduled'
  AND date(s.departure_time) >= date('now')
ORDER BY s.departure_time ASC;


-- --------------------------------------------------------------------
-- QUERY 2: Route Performance & Revenue Report
-- Concepts: Multi-Table JOIN, GROUP BY, Aggregate SUM, COUNT, AVG, ORDER BY
-- Purpose: Analyzes top-performing routes by passenger volume, total bookings,
--          gross revenue, and average ticket fare.
-- --------------------------------------------------------------------
SELECT 
    r.id AS route_id,
    r.source || ' -> ' || r.destination AS route_path,
    r.distance_km,
    COUNT(DISTINCT b.id) AS total_trips_scheduled,
    COUNT(DISTINCT bk.id) AS total_bookings_placed,
    COUNT(bp.id) AS total_passengers_travelled,
    ROUND(AVG(s.fare), 2) AS avg_ticket_fare,
    COALESCE(SUM(CASE WHEN bk.status = 'CONFIRMED' THEN bk.total_fare ELSE 0 END), 0) AS gross_confirmed_revenue
FROM routes r
JOIN schedules s ON s.route_id = r.id
LEFT JOIN bookings bk ON bk.schedule_id = s.id
LEFT JOIN booking_passengers bp ON bp.booking_id = bk.id AND bp.status = 'CONFIRMED'
GROUP BY r.id, route_path, r.distance_km
ORDER BY gross_confirmed_revenue DESC;


-- --------------------------------------------------------------------
-- QUERY 3: Fleet Occupancy & Utilization Metrics
-- Concepts: JOIN, GROUP BY, Mathematical Expression in Projection, ROUND
-- Purpose: Evaluates bus fleet efficiency by measuring occupancy percentages
--          (Seats Booked / Total Seat Capacity * 100).
-- --------------------------------------------------------------------
SELECT 
    b.id AS bus_id,
    b.bus_number,
    b.bus_name,
    b.bus_type,
    COUNT(DISTINCT s.id) AS total_schedules_assigned,
    (b.total_seats * COUNT(DISTINCT s.id)) AS total_seat_capacity_offered,
    COUNT(bp.id) AS actual_seats_booked,
    CASE 
        WHEN (b.total_seats * COUNT(DISTINCT s.id)) = 0 THEN 0.0
        ELSE ROUND(
            (CAST(COUNT(bp.id) AS REAL) / (b.total_seats * COUNT(DISTINCT s.id))) * 100, 
            2
        )
    END AS occupancy_percentage
FROM buses b
LEFT JOIN schedules s ON s.bus_id = b.id
LEFT JOIN booking_passengers bp ON bp.schedule_id = s.id AND bp.status = 'CONFIRMED'
GROUP BY b.id, b.bus_number, b.bus_name, b.bus_type, b.total_seats
ORDER BY occupancy_percentage DESC;


-- --------------------------------------------------------------------
-- QUERY 4: Customer Lifetime Expenditure & Cancellation History
-- Concepts: JOIN, GROUP BY, Conditional Aggregation (CASE WHEN), COALESCE
-- Purpose: Provides an audit log of each registered user's spending, 
--          cancellations, and refund breakdown.
-- --------------------------------------------------------------------
SELECT 
    u.id AS user_id,
    u.name AS customer_name,
    u.email AS customer_email,
    u.phone AS customer_phone,
    COUNT(b.id) AS total_bookings_created,
    SUM(CASE WHEN b.status = 'CONFIRMED' THEN 1 ELSE 0 END) AS confirmed_bookings,
    SUM(CASE WHEN b.status = 'CANCELLED' THEN 1 ELSE 0 END) AS cancelled_bookings,
    COALESCE(SUM(b.total_fare), 0) AS total_amount_booked,
    COALESCE(SUM(p.refund_amount), 0) AS total_refunds_claimed,
    (COALESCE(SUM(b.total_fare), 0) - COALESCE(SUM(p.refund_amount), 0)) AS net_spend
FROM users u
LEFT JOIN bookings b ON b.user_id = u.id
LEFT JOIN payments p ON p.booking_id = b.id
WHERE u.role = 'user'
GROUP BY u.id, u.name, u.email, u.phone
ORDER BY net_spend DESC;


-- --------------------------------------------------------------------
-- QUERY 5: Departure Time Slot Demand Analysis with HAVING Filter
-- Concepts: String Manipulation (strftime/substr), CASE expression, GROUP BY, HAVING
-- Purpose: Categorizes bus departures into diurnal time slots (Morning, 
--          Afternoon, Evening, Night) to identify peak travel windows.
-- --------------------------------------------------------------------
SELECT 
    CASE 
        WHEN CAST(strftime('%H', s.departure_time) AS INTEGER) BETWEEN 5 AND 11 THEN 'Morning (05:00 - 11:59)'
        WHEN CAST(strftime('%H', s.departure_time) AS INTEGER) BETWEEN 12 AND 16 THEN 'Afternoon (12:00 - 16:59)'
        WHEN CAST(strftime('%H', s.departure_time) AS INTEGER) BETWEEN 17 AND 21 THEN 'Evening (17:00 - 21:59)'
        ELSE 'Night (22:00 - 04:59)'
    END AS time_slot,
    COUNT(DISTINCT s.id) AS number_of_departures,
    COUNT(bp.id) AS total_passengers_booked,
    ROUND(AVG(s.fare), 2) AS average_fare
FROM schedules s
LEFT JOIN booking_passengers bp ON bp.schedule_id = s.id AND bp.status = 'CONFIRMED'
GROUP BY time_slot
HAVING number_of_departures > 0
ORDER BY total_passengers_booked DESC;
