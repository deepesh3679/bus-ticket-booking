# Bus Ticket Booking System - Database Schema & ER Diagram

This document describes the 3NF (Third Normal Form) Relational Database Schema and Entity-Relationship (ER) model for the Bus Ticket Booking System.

---

## 1. Entity-Relationship (ER) Diagram (Mermaid)

```mermaid
erDiagram
    USERS ||--o{ BOOKINGS : places
    BUSES ||--|{ SEATS : contains
    BUSES ||--o{ SCHEDULES : assigned_to
    ROUTES ||--o{ SCHEDULES : defines
    SCHEDULES ||--o{ BOOKINGS : scheduled_for
    SCHEDULES ||--o{ BOOKING_PASSENGERS : reserves_seat_in
    BOOKINGS ||--|{ BOOKING_PASSENGERS : includes
    BOOKINGS ||--|| PAYMENTS : settled_by

    USERS {
        INTEGER id PK
        TEXT name
        TEXT email UK
        TEXT password_hash
        TEXT phone
        TEXT role
        DATETIME created_at
    }

    BUSES {
        INTEGER id PK
        TEXT bus_number UK
        TEXT bus_name
        TEXT bus_type
        INTEGER total_seats
        DATETIME created_at
    }

    ROUTES {
        INTEGER id PK
        TEXT source
        TEXT destination
        REAL distance_km
        TEXT estimated_duration
        DATETIME created_at
    }

    SCHEDULES {
        INTEGER id PK
        INTEGER bus_id FK
        INTEGER route_id FK
        TEXT departure_time
        TEXT arrival_time
        REAL fare
        TEXT status
        DATETIME created_at
    }

    SEATS {
        INTEGER id PK
        INTEGER bus_id FK
        TEXT seat_number
        TEXT seat_type
        TEXT deck
    }

    BOOKINGS {
        INTEGER id PK
        TEXT pnr UK
        INTEGER user_id FK
        INTEGER schedule_id FK
        REAL total_fare
        TEXT status
        DATETIME booking_date
    }

    BOOKING_PASSENGERS {
        INTEGER id PK
        INTEGER booking_id FK
        INTEGER schedule_id FK
        TEXT seat_number
        TEXT passenger_name
        INTEGER passenger_age
        TEXT passenger_gender
        TEXT status
    }

    PAYMENTS {
        INTEGER id PK
        INTEGER booking_id FK
        REAL amount
        TEXT payment_method
        TEXT transaction_id UK
        TEXT status
        REAL refund_amount
        DATETIME created_at
    }
```

---

## 2. Table Specifications & 3NF Justification

### 1. `users`
- **PK**: `id`
- **Attributes**: `name`, `email`, `password_hash`, `phone`, `role`, `created_at`
- **Normalization (3NF)**: All attributes functionally depend solely on the primary key `id`. Role is constrained via `CHECK(role IN ('user', 'admin'))`. Email is uniquely indexed.

### 2. `buses`
- **PK**: `id`
- **Attributes**: `bus_number` (UK), `bus_name`, `bus_type`, `total_seats`, `created_at`
- **Normalization (3NF)**: Separates physical bus inventory from trips and schedules, preventing update anomalies when bus metadata changes.

### 3. `routes`
- **PK**: `id`
- **Attributes**: `source`, `destination`, `distance_km`, `estimated_duration`
- **Normalization (3NF)**: Route specifications are independent of physical buses or departure schedules. Unique constraint on `(source, destination)` prevents duplicate route entries.

### 4. `schedules`
- **PK**: `id`
- **FKs**: `bus_id` -> `buses(id)`, `route_id` -> `routes(id)`
- **Attributes**: `departure_time`, `arrival_time`, `fare`, `status`
- **Normalization (3NF)**: Maps a bus to a route at a specific date and time with its own fare. Avoids repeating route or bus details per trip.

### 5. `seats`
- **PK**: `id`
- **FK**: `bus_id` -> `buses(id)`
- **Attributes**: `seat_number`, `seat_type` ('window' | 'aisle'), `deck` ('lower' | 'upper')
- **Normalization (3NF)**: Static blueprint of physical seats per bus. `UNIQUE(bus_id, seat_number)` ensures no duplicate seat numbers per bus.

### 6. `bookings`
- **PK**: `id`
- **FKs**: `user_id` -> `users(id)`, `schedule_id` -> `schedules(id)`
- **Attributes**: `pnr` (UK), `total_fare`, `status` ('CONFIRMED' | 'CANCELLED'), `booking_date`
- **Normalization (3NF)**: Header record for a transaction. Stores customer reference, total billed amount, and current lifecycle state.

### 7. `booking_passengers`
- **PK**: `id`
- **FKs**: `booking_id` -> `bookings(id)`, `schedule_id` -> `schedules(id)`
- **Attributes**: `seat_number`, `passenger_name`, `passenger_age`, `passenger_gender`, `status`
- **Concurrency & Integrity Constraint**:
  ```sql
  CREATE UNIQUE INDEX idx_unique_active_seat 
  ON booking_passengers(schedule_id, seat_number) 
  WHERE status = 'CONFIRMED';
  ```
  This partial unique index prevents race condition double-booking at the relational engine level.

### 8. `payments`
- **PK**: `id`
- **FK**: `booking_id` -> `bookings(id)`
- **Attributes**: `amount`, `payment_method`, `transaction_id` (UK), `status`, `refund_amount`, `created_at`
- **Normalization (3NF)**: Financial transaction data is isolated from booking status, enabling partial/full refunds and audit trails.
