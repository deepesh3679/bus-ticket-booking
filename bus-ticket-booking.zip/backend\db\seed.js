require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('../config/db');

console.log('🌱 Starting Bus Ticket Booking System Database Seeding...');

const runSeed = db.transaction(() => {
  // Clear existing data in reverse order of foreign keys
  console.log('🧹 Clearing existing tables...');
  db.prepare('DELETE FROM payments').run();
  db.prepare('DELETE FROM booking_passengers').run();
  db.prepare('DELETE FROM bookings').run();
  db.prepare('DELETE FROM seats').run();
  db.prepare('DELETE FROM schedules').run();
  db.prepare('DELETE FROM routes').run();
  db.prepare('DELETE FROM buses').run();
  db.prepare('DELETE FROM users').run();

  // Reset sqlite_sequence counters
  try {
    db.prepare("DELETE FROM sqlite_sequence WHERE name IN ('users','buses','routes','schedules','seats','bookings','booking_passengers','payments')").run();
  } catch (e) {
    // sqlite_sequence might be empty
  }

  // 1. SEED USERS (1 Admin + 2 Demo Users)
  console.log('👤 Seeding Users...');
  const salt = bcrypt.genSaltSync(10);
  const adminHash = bcrypt.hashSync('Admin@123', salt);
  const userHash = bcrypt.hashSync('User@123', salt);

  const insertUser = db.prepare(`
    INSERT INTO users (name, email, password_hash, phone, role)
    VALUES (?, ?, ?, ?, ?)
  `);

  const adminId = insertUser.run('System Administrator', 'admin@busbooking.com', adminHash, '9876543210', 'admin').lastInsertRowid;
  const rahulId = insertUser.run('Rahul Sharma', 'rahul@example.com', userHash, '9812345678', 'user').lastInsertRowid;
  const priyaId = insertUser.run('Priya Patel', 'priya@example.com', userHash, '9898765432', 'user').lastInsertRowid;

  console.log(`   ✓ 3 Users created: Admin (admin@busbooking.com), Rahul (rahul@example.com), Priya (priya@example.com)`);

  // 2. SEED 5 ROUTES
  console.log('🛣️  Seeding 5 Routes...');
  const insertRoute = db.prepare(`
    INSERT INTO routes (source, destination, distance_km, estimated_duration)
    VALUES (?, ?, ?, ?)
  `);

  const r1 = insertRoute.run('Mumbai', 'Pune', 150, '3h 30m').lastInsertRowid;
  const r2 = insertRoute.run('Pune', 'Mumbai', 150, '3h 30m').lastInsertRowid;
  const r3 = insertRoute.run('Bangalore', 'Hyderabad', 570, '8h 30m').lastInsertRowid;
  const r4 = insertRoute.run('Delhi', 'Jaipur', 280, '5h 00m').lastInsertRowid;
  const r5 = insertRoute.run('Chennai', 'Bangalore', 350, '6h 00m').lastInsertRowid;

  console.log(`   ✓ 5 Routes seeded: Mumbai-Pune, Pune-Mumbai, Bangalore-Hyderabad, Delhi-Jaipur, Chennai-Bangalore`);

  // 3. SEED 10 BUSES & THEIR 40 SEATS
  console.log('🚌 Seeding 10 Buses & 400 Seats (2x2 Layout)...');
  const insertBus = db.prepare(`
    INSERT INTO buses (bus_number, bus_name, bus_type, total_seats)
    VALUES (?, ?, ?, ?)
  `);

  const insertSeat = db.prepare(`
    INSERT INTO seats (bus_id, seat_number, seat_type, deck)
    VALUES (?, ?, ?, 'lower')
  `);

  const busesData = [
    { number: 'MH-12-AB-1001', name: 'Orange Travels Sleeper Superfast', type: 'AC Sleeper' },
    { number: 'MH-12-CD-2002', name: 'Neeta Tours & Travels Express', type: 'AC Seater' },
    { number: 'KA-01-EF-3003', name: 'KSRTC Airavat Club Class', type: 'AC Sleeper' },
    { number: 'DL-01-GH-4004', name: 'Zingbus Royal Class', type: 'AC Seater' },
    { number: 'TN-09-IJ-5005', name: 'Parveen Travels Express', type: 'Non-AC Seater' },
    { number: 'MH-14-KL-6006', name: 'VRL Travels Multi-Axle', type: 'AC Sleeper' },
    { number: 'KA-05-MN-7007', name: 'SRS Travels Executive', type: 'Non-AC Sleeper' },
    { number: 'DL-04-OP-8008', name: 'IntrCity SmartBus Premium', type: 'AC Sleeper' },
    { number: 'TN-01-QR-9009', name: 'KPN Travels Star Liner', type: 'Non-AC Sleeper' },
    { number: 'KA-03-ST-1010', name: 'Greenline Travels Eco', type: 'Non-AC Seater' }
  ];

  const busIds = [];
  for (const b of busesData) {
    const busId = insertBus.run(b.number, b.name, b.type, 40).lastInsertRowid;
    busIds.push(busId);

    // Seed 40 seats per bus (2x2 layout)
    for (let seatNum = 1; seatNum <= 40; seatNum++) {
      const mod = seatNum % 4;
      const seatType = (mod === 1 || mod === 0) ? 'window' : 'aisle';
      insertSeat.run(busId, seatNum.toString(), seatType);
    }
  }
  console.log(`   ✓ 10 Buses & 400 Seats created.`);

  // 4. SEED SCHEDULES
  console.log('⏰ Seeding Bus Schedules (for multiple days)...');
  const insertSchedule = db.prepare(`
    INSERT INTO schedules (bus_id, route_id, departure_time, arrival_time, fare, status)
    VALUES (?, ?, ?, ?, ?, 'scheduled')
  `);

  // Helper to format ISO dates
  function getFutureDateTime(daysOffset, hours, minutes) {
    const d = new Date();
    d.setDate(d.getDate() + daysOffset);
    d.setHours(hours, minutes, 0, 0);
    const pad = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:00`;
  }

  const scheduleIds = [];
  // Day offsets: 0 (today), 1 (tomorrow), 2, 3
  const dayOffsets = [0, 1, 2, 3];

  dayOffsets.forEach(offset => {
    // Mumbai -> Pune (Route 1)
    scheduleIds.push(insertSchedule.run(busIds[0], r1, getFutureDateTime(offset, 6, 30), getFutureDateTime(offset, 10, 0), 450.0).lastInsertRowid);
    scheduleIds.push(insertSchedule.run(busIds[1], r1, getFutureDateTime(offset, 14, 0), getFutureDateTime(offset, 17, 30), 380.0).lastInsertRowid);
    scheduleIds.push(insertSchedule.run(busIds[5], r1, getFutureDateTime(offset, 22, 0), getFutureDateTime(offset, 25, 30), 550.0).lastInsertRowid); // 01:30 AM next day

    // Pune -> Mumbai (Route 2)
    scheduleIds.push(insertSchedule.run(busIds[0], r2, getFutureDateTime(offset, 11, 0), getFutureDateTime(offset, 14, 30), 450.0).lastInsertRowid);
    scheduleIds.push(insertSchedule.run(busIds[1], r2, getFutureDateTime(offset, 18, 30), getFutureDateTime(offset, 22, 0), 380.0).lastInsertRowid);

    // Bangalore -> Hyderabad (Route 3)
    scheduleIds.push(insertSchedule.run(busIds[2], r3, getFutureDateTime(offset, 21, 0), getFutureDateTime(offset + 1, 5, 30), 1150.0).lastInsertRowid);
    scheduleIds.push(insertSchedule.run(busIds[6], r3, getFutureDateTime(offset, 22, 30), getFutureDateTime(offset + 1, 7, 0), 850.0).lastInsertRowid);

    // Delhi -> Jaipur (Route 4)
    scheduleIds.push(insertSchedule.run(busIds[3], r4, getFutureDateTime(offset, 7, 0), getFutureDateTime(offset, 12, 0), 650.0).lastInsertRowid);
    scheduleIds.push(insertSchedule.run(busIds[7], r4, getFutureDateTime(offset, 16, 30), getFutureDateTime(offset, 21, 30), 800.0).lastInsertRowid);

    // Chennai -> Bangalore (Route 5)
    scheduleIds.push(insertSchedule.run(busIds[4], r5, getFutureDateTime(offset, 8, 0), getFutureDateTime(offset, 14, 0), 500.0).lastInsertRowid);
    scheduleIds.push(insertSchedule.run(busIds[8], r5, getFutureDateTime(offset, 23, 0), getFutureDateTime(offset + 1, 5, 0), 750.0).lastInsertRowid);
  });

  console.log(`   ✓ ${scheduleIds.length} Schedules created across ${dayOffsets.length} days.`);

  // 5. SEED INITIAL BOOKINGS FOR DEMO USERS
  console.log('🎟️  Seeding Demo Bookings & Payments...');
  const insertBooking = db.prepare(`
    INSERT INTO bookings (pnr, user_id, schedule_id, total_fare, status, booking_date)
    VALUES (?, ?, ?, ?, ?, datetime('now', '-2 hours'))
  `);

  const insertPassenger = db.prepare(`
    INSERT INTO booking_passengers (booking_id, schedule_id, seat_number, passenger_name, passenger_age, passenger_gender, status)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  const insertPayment = db.prepare(`
    INSERT INTO payments (booking_id, amount, payment_method, transaction_id, status, refund_amount)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  // Demo Booking 1: Rahul on Schedule 1 (Seats 1, 2)
  const sched1 = scheduleIds[0];
  const b1 = insertBooking.run('PNR-DEMO01', rahulId, sched1, 900.0, 'CONFIRMED').lastInsertRowid;
  insertPassenger.run(b1, sched1, '1', 'Rahul Sharma', 26, 'Male', 'CONFIRMED');
  insertPassenger.run(b1, sched1, '2', 'Sneha Sharma', 24, 'Female', 'CONFIRMED');
  insertPayment.run(b1, 900.0, 'UPI_GPAY', 'TXN-RAHUL-001', 'SUCCESS', 0.0);

  // Demo Booking 2: Priya on Schedule 6 (Bangalore -> Hyderabad, Seat 15)
  const sched3 = scheduleIds[5];
  const b2 = insertBooking.run('PNR-DEMO02', priyaId, sched3, 1150.0, 'CONFIRMED').lastInsertRowid;
  insertPassenger.run(b2, sched3, '15', 'Priya Patel', 28, 'Female', 'CONFIRMED');
  insertPayment.run(b2, 1150.0, 'NET_BANKING', 'TXN-PRIYA-002', 'SUCCESS', 0.0);

  console.log('   ✓ 2 Demo Bookings with PNR-DEMO01 and PNR-DEMO02 created.');
});

try {
  runSeed();
  console.log('\n✅ Database seeded successfully!');
  console.log('-------------------------------------------------------');
  console.log('Admin Login:   admin@busbooking.com / Admin@123');
  console.log('User 1 Login:  rahul@example.com   / User@123');
  console.log('User 2 Login:  priya@example.com   / User@123');
  console.log('-------------------------------------------------------');
} catch (error) {
  console.error('❌ Seeding failed:', error);
  process.exit(1);
}
