// Visual Seat Grid Selection & Passenger Booking Logic
let scheduleData = null;
let selectedSeats = new Set();

document.addEventListener('DOMContentLoaded', async () => {
  const params = new URLSearchParams(window.location.search);
  const scheduleId = params.get('scheduleId');

  if (!scheduleId) {
    showToast('No bus schedule selected.', 'error');
    setTimeout(() => window.location.href = 'index.html', 1500);
    return;
  }

  await loadSeatLayout(scheduleId);
});

// Fetch bus schedule and seat layout from API
async function loadSeatLayout(scheduleId) {
  const container = document.getElementById('seat-layout-section');
  if (!container) return;

  try {
    const res = await API.get(`/api/buses/schedules/${scheduleId}/seats`);
    scheduleData = res;

    // Render schedule summary header
    renderScheduleHeader(res.schedule);

    // Render 2x2 visual seat grid
    renderSeatGrid(res.seats);

    // Update checkout panel
    updateCheckoutPanel();

  } catch (err) {
    container.innerHTML = `
      <div style="background: var(--danger-light); color: var(--danger); padding: 1.5rem; border-radius: var(--radius-md); text-align: center;">
        ${err.message || 'Error loading seat blueprint.'}
      </div>
    `;
  }
}

// Render schedule trip banner
function renderScheduleHeader(sched) {
  const header = document.getElementById('schedule-trip-banner');
  if (!header) return;

  header.innerHTML = `
    <div style="background: var(--white); padding: 1.5rem; border-radius: var(--radius-lg); border: 1px solid var(--gray-200); box-shadow: var(--shadow-sm); margin-bottom: 2rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
      <div>
        <div style="font-size: 0.85rem; color: var(--gray-500); font-weight: 600; text-transform: uppercase;">Selected Route</div>
        <h2 style="font-size: 1.4rem; color: var(--gray-900);">${sched.source} ➔ ${sched.destination}</h2>
        <div style="font-size: 0.9rem; color: var(--gray-600); margin-top: 0.25rem;">
          <strong>${sched.bus_name}</strong> (${sched.bus_type}) • Reg: ${sched.bus_number}
        </div>
      </div>

      <div style="text-align: right;">
        <div style="font-size: 0.85rem; color: var(--gray-500);">Departure</div>
        <div style="font-size: 1.15rem; font-weight: 700; color: var(--gray-900);">${formatDateTime(sched.departure_time)}</div>
        <div style="font-size: 0.95rem; font-weight: 700; color: var(--primary); margin-top: 0.25rem;">
          ${formatCurrency(sched.fare)} <span style="font-size: 0.8rem; font-weight: 400; color: var(--gray-500);">/ seat</span>
        </div>
      </div>
    </div>
  `;
}

// Render 2x2 visual seat grid (40 seats across 10 rows)
function renderSeatGrid(seats) {
  const gridEl = document.getElementById('visual-seat-grid');
  if (!gridEl) return;

  // Organize 40 seats into 10 rows of 4 (Col 1, Col 2, AISLE, Col 3, Col 4)
  const rows = [];
  for (let i = 0; i < seats.length; i += 4) {
    rows.push(seats.slice(i, i + 4));
  }

  let html = '';
  rows.forEach((rowSeats, rowIndex) => {
    // rowSeats[0] = Col 1 (Window), rowSeats[1] = Col 2 (Aisle)
    // rowSeats[2] = Col 3 (Aisle),  rowSeats[3] = Col 4 (Window)
    const s1 = rowSeats[0];
    const s2 = rowSeats[1];
    const s3 = rowSeats[2];
    const s4 = rowSeats[3];

    html += `
      <div class="seat-row">
        ${renderSeatButton(s1)}
        ${renderSeatButton(s2)}
        <div class="aisle-space">R${rowIndex + 1}</div>
        ${renderSeatButton(s3)}
        ${renderSeatButton(s4)}
      </div>
    `;
  });

  gridEl.innerHTML = html;
}

function renderSeatButton(seat) {
  if (!seat) return '<div></div>';

  const isBooked = seat.is_booked;
  const isSelected = selectedSeats.has(seat.seat_number);

  let classes = 'seat-btn';
  if (isBooked) classes += ' booked';
  if (isSelected) classes += ' selected';

  return `
    <button type="button" 
      class="${classes}" 
      data-seat="${seat.seat_number}"
      title="Seat ${seat.seat_number} (${seat.seat_type}) ${isBooked ? '- Already Booked' : '- Available'}"
      ${isBooked ? 'disabled' : `onclick="toggleSeatSelection('${seat.seat_number}')"`}
    >
      <span>${seat.seat_number}</span>
      <span style="font-size: 0.65rem; font-weight: 500; opacity: 0.7;">${seat.seat_type === 'window' ? 'W' : 'A'}</span>
    </button>
  `;
}

// Toggle seat selection
function toggleSeatSelection(seatNumber) {
  if (selectedSeats.has(seatNumber)) {
    selectedSeats.delete(seatNumber);
  } else {
    // Max 6 seats per booking
    if (selectedSeats.size >= 6) {
      showToast('You can select a maximum of 6 seats per booking.', 'warning');
      return;
    }
    selectedSeats.add(seatNumber);
  }

  // Update button visual state
  const btn = document.querySelector(`button[data-seat="${seatNumber}"]`);
  if (btn) {
    btn.classList.toggle('selected', selectedSeats.has(seatNumber));
  }

  // Refresh passenger form and fare summary
  updateCheckoutPanel();
}

// Update checkout panel with passenger fields and fare total
function updateCheckoutPanel() {
  const panel = document.getElementById('checkout-panel-content');
  if (!panel || !scheduleData) return;

  const farePerSeat = scheduleData.schedule.fare;
  const seatList = Array.from(selectedSeats).sort((a, b) => Number(a) - Number(b));
  const totalFare = seatList.length * farePerSeat;

  if (seatList.length === 0) {
    panel.innerHTML = `
      <div style="text-align: center; padding: 2.5rem 1rem; color: var(--gray-400);">
        <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">💺</div>
        <p style="font-weight: 600; color: var(--gray-600);">No Seats Selected</p>
        <p style="font-size: 0.85rem; margin-top: 0.25rem;">Click on any available green seat in the bus layout to begin booking.</p>
      </div>
    `;
    return;
  }

  let passengersHtml = '';
  seatList.forEach((seatNum, idx) => {
    passengersHtml += `
      <div class="passenger-entry">
        <div class="passenger-entry-title">Seat ${seatNum} Passenger Details</div>
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 0.5rem; margin-bottom: 0.5rem;">
          <input type="text" class="form-control" id="p-name-${seatNum}" placeholder="Full Name" required />
          <input type="number" class="form-control" id="p-age-${seatNum}" placeholder="Age" min="1" max="110" required />
        </div>
        <select class="form-control" id="p-gender-${seatNum}">
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Other">Other</option>
        </select>
      </div>
    `;
  });

  panel.innerHTML = `
    <div>
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
        <span style="font-weight: 600;">Selected Seats (${seatList.length}):</span>
        <span style="background: var(--primary-light); color: var(--primary); font-weight: 700; padding: 0.2rem 0.6rem; border-radius: var(--radius-sm);">
          ${seatList.join(', ')}
        </span>
      </div>

      <form id="booking-passenger-form" onsubmit="handleConfirmBooking(event)">
        <div style="max-height: 280px; overflow-y: auto; padding-right: 0.25rem;">
          ${passengersHtml}
        </div>

        <div class="fare-breakdown">
          <div class="fare-row">
            <span>Ticket Fare (${seatList.length} × ${formatCurrency(farePerSeat)})</span>
            <span>${formatCurrency(totalFare)}</span>
          </div>
          <div class="fare-row">
            <span>Taxes & GST (0% Mock)</span>
            <span>₹0</span>
          </div>
          <div class="fare-row fare-total">
            <span>Total Payable</span>
            <span style="color: var(--primary);">${formatCurrency(totalFare)}</span>
          </div>
        </div>

        <div class="form-group" style="margin-bottom: 1.25rem;">
          <label style="font-size: 0.85rem; font-weight: 600;">Payment Method</label>
          <select class="form-control" id="payment-method-select">
            <option value="MOCK_UPI">Mock UPI (GPay / PhonePe / Paytm)</option>
            <option value="MOCK_DEBIT_CARD">Mock Debit / Credit Card</option>
            <option value="MOCK_NET_BANKING">Mock Net Banking</option>
          </select>
        </div>

        <button type="submit" class="btn btn-primary" style="width: 100%; padding: 0.85rem;" id="confirm-booking-btn">
          🔒 Pay & Confirm Booking (${formatCurrency(totalFare)})
        </button>
      </form>
    </div>
  `;
}

// Handle Form Submission & Transaction API Call
async function handleConfirmBooking(e) {
  e.preventDefault();

  // Enforce Login
  const user = API.getUser();
  if (!user) {
    showToast('Please login to complete your booking.', 'info');
    const returnUrl = encodeURIComponent(window.location.pathname + window.location.search);
    setTimeout(() => {
      window.location.href = `login.html?returnUrl=${returnUrl}`;
    }, 600);
    return;
  }

  const seatList = Array.from(selectedSeats);
  const passengers = [];

  for (const seatNum of seatList) {
    const nameInput = document.getElementById(`p-name-${seatNum}`);
    const ageInput = document.getElementById(`p-age-${seatNum}`);
    const genderSelect = document.getElementById(`p-gender-${seatNum}`);

    const name = nameInput ? nameInput.value.trim() : '';
    const age = ageInput ? ageInput.value.trim() : '';
    const gender = genderSelect ? genderSelect.value : 'Other';

    if (!name || !age) {
      showToast(`Please enter name and age for Seat ${seatNum}.`, 'error');
      return;
    }

    passengers.push({
      seat_number: seatNum,
      passenger_name: name,
      passenger_age: Number(age),
      passenger_gender: gender
    });
  }

  const paymentMethod = document.getElementById('payment-method-select').value;
  const btn = document.getElementById('confirm-booking-btn');
  btn.disabled = true;
  btn.innerText = '⏳ Processing SQL Transaction...';

  try {
    const res = await API.post('/api/bookings', {
      schedule_id: scheduleData.schedule.schedule_id,
      passengers,
      payment_method: paymentMethod
    });

    showToast(res.message || 'Booking Confirmed!', 'success');
    showPNRSuccessModal(res.booking);

  } catch (err) {
    showToast(err.message, 'error');
    btn.disabled = false;
    btn.innerText = `🔒 Pay & Confirm Booking`;
  }
}

// Show PNR Success Modal
function showPNRSuccessModal(booking) {
  const modal = document.getElementById('booking-success-modal');
  if (!modal) return;

  const content = document.getElementById('pnr-modal-content');
  content.innerHTML = `
    <div style="text-align: center; margin-bottom: 1.5rem;">
      <div style="width: 60px; height: 60px; background: var(--success-light); color: var(--success); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 2rem; margin: 0 auto 0.75rem;">
        ✓
      </div>
      <h3 style="font-size: 1.4rem; color: var(--gray-900);">Booking Confirmed!</h3>
      <p style="color: var(--gray-500); font-size: 0.9rem;">Your e-ticket has been generated with ACID database guarantee.</p>
    </div>

    <div style="background: var(--gray-50); border: 1.5px dashed var(--gray-300); border-radius: var(--radius-md); padding: 1.25rem; margin-bottom: 1.5rem;">
      <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--gray-200); padding-bottom: 0.75rem; margin-bottom: 0.75rem;">
        <span style="font-size: 0.85rem; color: var(--gray-500); font-weight: 600;">PNR NUMBER</span>
        <span style="font-size: 1.3rem; font-weight: 800; color: var(--primary); letter-spacing: 1px;">${booking.pnr}</span>
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; font-size: 0.85rem; margin-bottom: 0.75rem;">
        <div>
          <span style="color: var(--gray-500);">Route:</span>
          <div style="font-weight: 600;">${booking.source} ➔ ${booking.destination}</div>
        </div>
        <div>
          <span style="color: var(--gray-500);">Bus:</span>
          <div style="font-weight: 600;">${booking.bus_name}</div>
        </div>
        <div>
          <span style="color: var(--gray-500);">Departure:</span>
          <div style="font-weight: 600;">${formatDateTime(booking.departure_time)}</div>
        </div>
        <div>
          <span style="color: var(--gray-500);">Seats:</span>
          <div style="font-weight: 700; color: var(--primary);">${booking.seats.join(', ')}</div>
        </div>
      </div>

      <div style="border-top: 1px solid var(--gray-200); padding-top: 0.75rem; display: flex; justify-content: space-between; align-items: center;">
        <span style="font-size: 0.85rem; color: var(--gray-500);">Total Amount Paid:</span>
        <span style="font-size: 1.15rem; font-weight: 800; color: var(--gray-900);">${formatCurrency(booking.total_fare)}</span>
      </div>
      <div style="font-size: 0.75rem; color: var(--gray-400); margin-top: 0.25rem; text-align: right;">Txn: ${booking.transaction_id}</div>
    </div>

    <div style="display: flex; gap: 0.75rem;">
      <a href="my-bookings.html" class="btn btn-primary" style="flex: 1;">View in My Bookings</a>
      <button class="btn btn-secondary" onclick="window.print()">🖨️ Print Ticket</button>
    </div>
  `;

  modal.classList.add('active');
}
