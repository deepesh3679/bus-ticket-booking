// Automated End-to-End Test Suite for Bus Ticket Booking System
const http = require('http');
const app = require('./backend/server');
const db = require('./backend/config/db');

const PORT = 5055;
let server;
let authToken = '';
let testUserId = null;
let testScheduleId = null;
let testBookingId = null;
let testPNR = null;

// Helper to make HTTP requests
function request(method, path, body = null, token = null) {
  return new Promise((resolve, reject) => {
    const postData = body ? JSON.stringify(body) : null;
    const options = {
      hostname: 'localhost',
      port: PORT,
      path,
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(postData ? { 'Content-Length': Buffer.byteLength(postData) } : {}),
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      }
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve({ status: res.statusCode, body: parsed });
        } catch (e) {
          resolve({ status: res.statusCode, body: data });
        }
      });
    });

    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

async function runTests() {
  console.log('\n=============================================================');
  console.log('🧪 Starting Bus Ticket Booking System End-to-End Test Suite');
  console.log('=============================================================\n');

  try {
    // 1. Health check
    console.log('1️⃣  Testing Health Check Endpoint...');
    const health = await request('GET', '/api/health');
    if (health.status !== 200 || health.body.status !== 'OK') {
      throw new Error(`Health check failed: ${JSON.stringify(health)}`);
    }
    console.log('   ✓ Backend server is healthy & responding.');

    // 2. User Signup
    console.log('\n2️⃣  Testing User Signup Flow...');
    const testEmail = `testuser_${Date.now()}@example.com`;
    const signupRes = await request('POST', '/api/auth/register', {
      name: 'Rohan Verma',
      email: testEmail,
      password: 'Password@123',
      phone: '9988776655'
    });
    if (signupRes.status !== 201 || !signupRes.body.token) {
      throw new Error(`Signup failed: ${JSON.stringify(signupRes)}`);
    }
    testUserId = signupRes.body.user.id;
    console.log(`   ✓ New user registered: ID #${testUserId} (${testEmail})`);

    // 3. User Login
    console.log('\n3️⃣  Testing User Login Flow & JWT Verification...');
    const loginRes = await request('POST', '/api/auth/login', {
      email: testEmail,
      password: 'Password@123'
    });
    if (loginRes.status !== 200 || !loginRes.body.token) {
      throw new Error(`Login failed: ${JSON.stringify(loginRes)}`);
    }
    authToken = loginRes.body.token;
    console.log(`   ✓ Login successful. JWT token received.`);

    // 4. Search Buses
    console.log('\n4️⃣  Testing Bus Search (Mumbai -> Pune)...');
    const searchRes = await request('GET', '/api/buses/search?source=Mumbai&destination=Pune');
    if (searchRes.status !== 200 || !searchRes.body.schedules || searchRes.body.schedules.length === 0) {
      throw new Error(`Bus search failed: ${JSON.stringify(searchRes)}`);
    }
    console.log(`   ✓ Found ${searchRes.body.schedules.length} scheduled buses for Mumbai -> Pune.`);
    testScheduleId = searchRes.body.schedules[0].schedule_id;
    console.log(`   ✓ Selected Schedule ID #${testScheduleId} (${searchRes.body.schedules[0].bus_name}, Fare: ₹${searchRes.body.schedules[0].fare})`);

    // 5. Fetch Seat Layout
    console.log('\n5️⃣  Testing Visual Seat Grid Retrieval...');
    const seatsRes = await request('GET', `/api/buses/schedules/${testScheduleId}/seats`);
    if (seatsRes.status !== 200 || !seatsRes.body.seats || seatsRes.body.seats.length !== 40) {
      throw new Error(`Seat fetch failed: ${JSON.stringify(seatsRes)}`);
    }
    console.log(`   ✓ Retrieved 40 seats blueprint. Available: ${seatsRes.body.available_seats}, Booked: ${seatsRes.body.booked_count}`);

    // 6. Multi-Seat Booking (ACID Transaction)
    console.log('\n6️⃣  Testing Multi-Seat Booking (Seats 21 & 22)...');
    const bookingRes = await request('POST', '/api/bookings', {
      schedule_id: testScheduleId,
      passengers: [
        { seat_number: '21', passenger_name: 'Rohan Verma', passenger_age: 24, passenger_gender: 'Male' },
        { seat_number: '22', passenger_name: 'Ananya Verma', passenger_age: 22, passenger_gender: 'Female' }
      ],
      payment_method: 'MOCK_UPI'
    }, authToken);

    if (bookingRes.status !== 201 || !bookingRes.body.booking) {
      throw new Error(`Booking failed: ${JSON.stringify(bookingRes)}`);
    }
    testBookingId = bookingRes.body.booking.id;
    testPNR = bookingRes.body.booking.pnr;
    console.log(`   ✓ Booking Confirmed! PNR: ${testPNR}, Total Fare: ₹${bookingRes.body.booking.total_fare}, Txn: ${bookingRes.body.booking.transaction_id}`);

    // 7. Test Concurrency / Double-Booking Prevention
    console.log('\n7️⃣  Testing Concurrency & Double-Booking Prevention on Seat 21...');
    const conflictRes = await request('POST', '/api/bookings', {
      schedule_id: testScheduleId,
      passengers: [
        { seat_number: '21', passenger_name: 'Imposter User', passenger_age: 30, passenger_gender: 'Male' }
      ]
    }, authToken);

    if (conflictRes.status !== 409) {
      throw new Error(`Concurrency test failed! Expected 409 Conflict but got ${conflictRes.status}`);
    }
    console.log(`   ✓ Double-booking rejected cleanly by database constraint: "${conflictRes.body.error}"`);

    // 8. View My Bookings
    console.log('\n8️⃣  Testing "My Bookings" Page Retrieval...');
    const myBookingsRes = await request('GET', '/api/bookings/my-bookings', null, authToken);
    if (myBookingsRes.status !== 200 || !myBookingsRes.body.bookings) {
      throw new Error(`My bookings failed: ${JSON.stringify(myBookingsRes)}`);
    }
    const foundBooking = myBookingsRes.body.bookings.find(b => b.pnr === testPNR);
    if (!foundBooking) {
      throw new Error(`Could not find booking ${testPNR} in user booking history`);
    }
    console.log(`   ✓ Booking found in history. Status: ${foundBooking.booking_status}, Eligible Refund: ${foundBooking.eligibleRefundPercent}% (₹${foundBooking.estimatedRefund})`);

    // 9. Cancel Booking & Refund Calculation
    console.log('\n9️⃣  Testing Ticket Cancellation & Refund Calculation...');
    const cancelRes = await request('POST', `/api/bookings/${testBookingId}/cancel`, {}, authToken);
    if (cancelRes.status !== 200 || !cancelRes.body.cancellation) {
      throw new Error(`Cancellation failed: ${JSON.stringify(cancelRes)}`);
    }
    console.log(`   ✓ Cancellation processed! Refund: ${cancelRes.body.cancellation.refund_percentage} (₹${cancelRes.body.cancellation.refund_amount})`);

    // 10. Verify Seat Release
    console.log('\n🔟 Testing Seat Release in Visual Blueprint...');
    const seatsAfterRes = await request('GET', `/api/buses/schedules/${testScheduleId}/seats`);
    const seat21 = seatsAfterRes.body.seats.find(s => s.seat_number === '21');
    const seat22 = seatsAfterRes.body.seats.find(s => s.seat_number === '22');
    if (seat21.is_booked || seat22.is_booked) {
      throw new Error(`Seats 21 and 22 were not released after cancellation!`);
    }
    console.log(`   ✓ Seats 21 and 22 are now available again for other passengers.`);

    // 11. Admin Panel Verification
    console.log('\n1️⃣1️⃣ Testing Admin Role-Protected Endpoints...');
    const adminLoginRes = await request('POST', '/api/auth/login', {
      email: 'admin@busbooking.com',
      password: 'Admin@123'
    });
    const adminToken = adminLoginRes.body.token;
    const statsRes = await request('GET', '/api/admin/stats', null, adminToken);
    if (statsRes.status !== 200 || statsRes.body.totalBuses !== 10) {
      throw new Error(`Admin stats failed: ${JSON.stringify(statsRes)}`);
    }
    console.log(`   ✓ Admin access granted. Fleet: ${statsRes.body.totalBuses} buses, Routes: ${statsRes.body.totalRoutes}, Net Revenue: ₹${statsRes.body.revenue.net_revenue}`);

    // 12. Run 5 Sample Queries
    console.log('\n1️⃣2️⃣ Executing 5 Sample Analytical Viva Queries...');
    // Query 1
    const q1 = db.prepare(`
      SELECT s.id, b.bus_name, r.source, r.destination, s.fare,
      (b.total_seats - (SELECT COUNT(bp.id) FROM booking_passengers bp WHERE bp.schedule_id = s.id AND bp.status = 'CONFIRMED')) as available_seats
      FROM schedules s JOIN buses b ON s.bus_id = b.id JOIN routes r ON s.route_id = r.id
      WHERE LOWER(r.source) = 'mumbai' AND LOWER(r.destination) = 'pune' LIMIT 1
    `).get();
    console.log('   ✓ Query 1 (Bus Search & Available Seats):', q1.bus_name, 'Available:', q1.available_seats);

    // Query 2
    const q2 = db.prepare(`
      SELECT r.source || ' -> ' || r.destination AS route_path, COUNT(DISTINCT s.id) as trips
      FROM routes r JOIN schedules s ON s.route_id = r.id GROUP BY r.id LIMIT 1
    `).get();
    console.log('   ✓ Query 2 (Route Performance):', q2.route_path, 'Trips:', q2.trips);

    // Query 3
    const q3 = db.prepare(`
      SELECT b.bus_name, b.total_seats, COUNT(bp.id) as booked
      FROM buses b LEFT JOIN schedules s ON s.bus_id = b.id
      LEFT JOIN booking_passengers bp ON bp.schedule_id = s.id AND bp.status = 'CONFIRMED'
      GROUP BY b.id LIMIT 1
    `).get();
    console.log('   ✓ Query 3 (Fleet Occupancy):', q3.bus_name, 'Total Seats:', q3.total_seats);

    // Query 4
    const q4 = db.prepare(`
      SELECT u.name, COUNT(b.id) as bookings
      FROM users u LEFT JOIN bookings b ON b.user_id = u.id WHERE u.role = 'user' GROUP BY u.id LIMIT 1
    `).get();
    console.log('   ✓ Query 4 (Customer History):', q4.name, 'Bookings:', q4.bookings);

    // Query 5
    const q5 = db.prepare(`
      SELECT CASE WHEN CAST(strftime('%H', departure_time) AS INTEGER) BETWEEN 5 AND 11 THEN 'Morning' ELSE 'Other' END as slot, COUNT(*) as count
      FROM schedules GROUP BY slot LIMIT 1
    `).get();
    console.log('   ✓ Query 5 (Departure Time Slot Demand):', q5.slot, 'Count:', q5.count);

    console.log('\n=============================================================');
    console.log('🎉 ALL 12 INTEGRATION TESTS PASSED WITH 100% SUCCESS!');
    console.log('=============================================================\n');

  } catch (error) {
    console.error('\n❌ Test Suite Failed:', error.message);
    process.exit(1);
  } finally {
    if (server) server.close();
    process.exit(0);
  }
}

// Start test server
server = app.listen(PORT, () => {
  runTests();
});
