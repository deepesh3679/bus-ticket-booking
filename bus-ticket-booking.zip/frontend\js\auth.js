// Authentication management and navigation state
document.addEventListener('DOMContentLoaded', () => {
  renderNavbar();
});

function renderNavbar() {
  const authNav = document.getElementById('nav-auth-section');
  if (!authNav) return;

  const user = API.getUser();
  const token = API.getToken();

  if (user && token) {
    authNav.innerHTML = `
      <div class="user-badge">
        <span>👤 ${user.name}</span>
        <span class="role-tag">${user.role}</span>
      </div>
      ${user.role === 'admin' ? '<a href="admin.html" class="btn btn-secondary btn-sm">Admin Panel</a>' : ''}
      <button class="btn btn-secondary btn-sm" onclick="logoutUser()">Logout</button>
    `;
  } else {
    authNav.innerHTML = `
      <a href="login.html" class="btn btn-secondary btn-sm">Login</a>
      <a href="register.html" class="btn btn-primary btn-sm">Register</a>
    `;
  }
}

async function loginUser(email, password) {
  try {
    const res = await API.post('/api/auth/login', { email, password });
    API.setToken(res.token);
    API.setUser(res.user);
    showToast(res.message || 'Login successful!', 'success');
    
    setTimeout(() => {
      if (res.user.role === 'admin') {
        window.location.href = 'admin.html';
      } else {
        const returnUrl = new URLSearchParams(window.location.search).get('returnUrl');
        window.location.href = returnUrl || 'index.html';
      }
    }, 600);
  } catch (err) {
    showToast(err.message, 'error');
    throw err;
  }
}

async function registerUser(userData) {
  try {
    const res = await API.post('/api/auth/register', userData);
    API.setToken(res.token);
    API.setUser(res.user);
    showToast('Registration successful!', 'success');
    
    setTimeout(() => {
      window.location.href = 'index.html';
    }, 600);
  } catch (err) {
    showToast(err.message, 'error');
    throw err;
  }
}

function logoutUser() {
  API.setToken(null);
  API.setUser(null);
  showToast('Logged out successfully.', 'info');
  setTimeout(() => {
    window.location.href = 'login.html';
  }, 400);
}

function requireAuth(role = null) {
  const user = API.getUser();
  const token = API.getToken();

  if (!user || !token) {
    showToast('Please login to continue.', 'error');
    const returnUrl = encodeURIComponent(window.location.pathname + window.location.search);
    window.location.href = `login.html?returnUrl=${returnUrl}`;
    return false;
  }

  if (role && user.role !== role) {
    showToast(`Access restricted. Requires ${role} privileges.`, 'error');
    window.location.href = 'index.html';
    return false;
  }

  return true;
}
