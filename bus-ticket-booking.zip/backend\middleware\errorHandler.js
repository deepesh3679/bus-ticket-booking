// Central Express error handling middleware
const errorHandler = (err, req, res, next) => {
  console.error(`[Error] ${req.method} ${req.url} - ${err.message}`);
  
  // SQLite unique constraint violation
  if (err.code === 'SQLITE_CONSTRAINT_UNIQUE' || err.message.includes('UNIQUE constraint failed')) {
    return res.status(409).json({
      error: 'Conflict: A record or seat with these details already exists.',
      details: err.message
    });
  }

  // SQLite foreign key violation
  if (err.code === 'SQLITE_CONSTRAINT_FOREIGNKEY') {
    return res.status(400).json({
      error: 'Invalid reference: Related record does not exist.',
      details: err.message
    });
  }

  // SQLite check constraint violation
  if (err.code === 'SQLITE_CONSTRAINT_CHECK') {
    return res.status(400).json({
      error: 'Validation failed: Check constraint violated.',
      details: err.message
    });
  }

  // Generic fallback error
  res.status(err.status || 500).json({
    error: err.message || 'Internal Server Error',
    ...(process.env.NODE_ENV === 'development' ? { stack: err.stack } : {})
  });
};

module.exports = errorHandler;
