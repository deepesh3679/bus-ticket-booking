const express = require('express');
const router = express.Router();
const { getCities, searchBuses, getScheduleSeats } = require('../controllers/busController');

router.get('/cities', getCities);
router.get('/search', searchBuses);
router.get('/schedules/:scheduleId/seats', getScheduleSeats);

module.exports = router;
