// Admin Dashboard & Management Logic
let currentTab = 'stats';
let allBuses = [];
let allRoutes = [];

document.addEventListener('DOMContentLoaded', async () => {
  if (!requireAuth('admin')) return;

  // Tab switching setup
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentTab = btn.dataset.tab;
      loadActiveTab();
    });
  });

  await loadActiveTab();
});

async function loadActiveTab() {
  switch (currentTab) {
    case 'stats':
      await loadStats();
      break;
    case 'buses':
      await loadBuses();
      break;
    case 'routes':
      await loadRoutes();
      break;
    case 'schedules':
      await loadSchedules();
      break;
    case 'bookings':
      await loadBookings();
      break;
  }
}

// --------------------------------------------------------------------
// 1. DASHBOARD STATS
// --------------------------------------------------------------------
async function loadStats() {
  const container = document.getElementById('admin-tab-content');
  try {
    const data = await API.get('/api/admin/stats');
    container.innerHTML = `
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon">💰</div>
          <div>
            <div class="stat-val">${formatCurrency(data.revenue.net_revenue || 0)}</div>
            <div class="stat-lbl">Net Revenue (Gross: ${formatCurrency(data.revenue.gross_revenue || 0)})</div>
          </div>
        </div>

        <div class="stat-card">
          <div class="stat-icon">🎟️</div>
          <div>
            <div class="stat-val">${data.totalBookings}</div>
            <div class="stat-lbl">Total Bookings (${data.confirmedBookings} active, ${data.cancelledBookings} cancelled)</div>
          </div>
        </div>

        <div class="stat-card">
          <div class="stat-icon">🚌</div>
          <div>
            <div class="stat-val">${data.totalBuses}</div>
            <div class="stat-lbl">Fleet Buses Registered</div>
          </div>
        </div>

        <div class="stat-card">
          <div class="stat-icon">🛣️</div>
          <div>
            <div class="stat-val">${data.totalRoutes}</div>
            <div class="stat-lbl">Connected Routes (${data.totalSchedules} trips)</div>
          </div>
        </div>
      </div>

      <div style="background: var(--white); border-radius: var(--radius-lg); padding: 2rem; border: 1px solid var(--gray-200); box-shadow: var(--shadow-sm); margin-top: 1.5rem;">
        <h3 style="font-size: 1.2rem; margin-bottom: 0.75rem;">DBMS Project Admin Overview</h3>
        <p style="color: var(--gray-600); font-size: 0.95rem; line-height: 1.6;">
          This administration portal interacts directly with the SQLite database via normalized relational tables and transaction-safe API endpoints. 
          Use the tabs above to manage physical buses, geographical routes, travel schedules, and inspect system-wide customer bookings.
        </p>
      </div>
    `;
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// --------------------------------------------------------------------
// 2. BUSES MANAGEMENT
// --------------------------------------------------------------------
async function loadBuses() {
  const container = document.getElementById('admin-tab-content');
  try {
    const res = await API.get('/api/admin/buses');
    allBuses = res.buses;

    container.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem;">
        <h3 style="font-size: 1.25rem;">Fleet Buses (${res.buses.length})</h3>
        <button class="btn btn-primary btn-sm" onclick="openAddBusModal()">+ Add New Bus</button>
      </div>

      <div class="table-container">
        <table class="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Bus Number</th>
              <th>Bus Name</th>
              <th>Type</th>
              <th>Seats</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            ${res.buses.map(b => `
              <tr>
                <td>#${b.id}</td>
                <td><strong>${b.bus_number}</strong></td>
                <td>${b.bus_name}</td>
                <td><span class="badge badge-info">${b.bus_type}</span></td>
                <td>${b.total_seats} seats</td>
                <td>
                  <button class="btn btn-secondary btn-sm" onclick="openEditBusModal(${b.id}, '${b.bus_name}', '${b.bus_type}')">Edit</button>
                  <button class="btn btn-danger btn-sm" onclick="deleteBus(${b.id})">Delete</button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function openAddBusModal() {
  const modal = document.getElementById('admin-action-modal');
  const title = document.getElementById('admin-modal-title');
  const body = document.getElementById('admin-modal-body');

  title.innerText = 'Add New Bus';
  body.innerHTML = `
    <form onsubmit="handleAddBus(event)">
      <div class="form-group" style="margin-bottom: 1rem;">
        <label>Bus Registration Number</label>
        <input type="text" class="form-control" id="modal-bus-number" placeholder="e.g. MH-12-XX-9999" required />
      </div>
      <div class="form-group" style="margin-bottom: 1rem;">
        <label>Bus Operator / Fleet Name</label>
        <input type="text" class="form-control" id="modal-bus-name" placeholder="e.g. Royal Travels Multi-Axle" required />
      </div>
      <div class="form-group" style="margin-bottom: 1rem;">
        <label>Bus Type</label>
        <select class="form-control" id="modal-bus-type">
          <option value="AC Sleeper">AC Sleeper</option>
          <option value="AC Seater">AC Seater</option>
          <option value="Non-AC Sleeper">Non-AC Sleeper</option>
          <option value="Non-AC Seater">Non-AC Seater</option>
        </select>
      </div>
      <div class="form-group" style="margin-bottom: 1.5rem;">
        <label>Total Seats</label>
        <input type="number" class="form-control" id="modal-bus-seats" value="40" min="20" max="60" required />
        <small style="color: var(--gray-400);">Will automatically generate 2x2 seat blueprint in database.</small>
      </div>
      <button type="submit" class="btn btn-primary" style="width: 100%;">Create Bus</button>
    </form>
  `;
  modal.classList.add('active');
}

async function handleAddBus(e) {
  e.preventDefault();
  const bus_number = document.getElementById('modal-bus-number').value.trim();
  const bus_name = document.getElementById('modal-bus-name').value.trim();
  const bus_type = document.getElementById('modal-bus-type').value;
  const total_seats = document.getElementById('modal-bus-seats').value;

  try {
    await API.post('/api/admin/buses', { bus_number, bus_name, bus_type, total_seats });
    closeAdminModal();
    showToast('Bus added successfully!', 'success');
    await loadBuses();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function openEditBusModal(id, name, type) {
  const modal = document.getElementById('admin-action-modal');
  const title = document.getElementById('admin-modal-title');
  const body = document.getElementById('admin-modal-body');

  title.innerText = `Edit Bus #${id}`;
  body.innerHTML = `
    <form onsubmit="handleEditBus(event, ${id})">
      <div class="form-group" style="margin-bottom: 1rem;">
        <label>Bus Name</label>
        <input type="text" class="form-control" id="modal-edit-bus-name" value="${name}" required />
      </div>
      <div class="form-group" style="margin-bottom: 1.5rem;">
        <label>Bus Type</label>
        <select class="form-control" id="modal-edit-bus-type">
          <option value="AC Sleeper" ${type === 'AC Sleeper' ? 'selected' : ''}>AC Sleeper</option>
          <option value="AC Seater" ${type === 'AC Seater' ? 'selected' : ''}>AC Seater</option>
          <option value="Non-AC Sleeper" ${type === 'Non-AC Sleeper' ? 'selected' : ''}>Non-AC Sleeper</option>
          <option value="Non-AC Seater" ${type === 'Non-AC Seater' ? 'selected' : ''}>Non-AC Seater</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary" style="width: 100%;">Save Changes</button>
    </form>
  `;
  modal.classList.add('active');
}

async function handleEditBus(e, id) {
  e.preventDefault();
  const bus_name = document.getElementById('modal-edit-bus-name').value.trim();
  const bus_type = document.getElementById('modal-edit-bus-type').value;

  try {
    await API.put(`/api/admin/buses/${id}`, { bus_name, bus_type });
    closeAdminModal();
    showToast('Bus updated successfully!', 'success');
    await loadBuses();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function deleteBus(id) {
  if (!confirm(`Are you sure you want to delete Bus #${id}? All related schedules will also be removed.`)) return;
  try {
    await API.delete(`/api/admin/buses/${id}`);
    showToast('Bus deleted successfully.', 'info');
    await loadBuses();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// --------------------------------------------------------------------
// 3. ROUTES MANAGEMENT
// --------------------------------------------------------------------
async function loadRoutes() {
  const container = document.getElementById('admin-tab-content');
  try {
    const res = await API.get('/api/admin/routes');
    allRoutes = res.routes;

    container.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem;">
        <h3 style="font-size: 1.25rem;">Connected Routes (${res.routes.length})</h3>
        <button class="btn btn-primary btn-sm" onclick="openAddRouteModal()">+ Add New Route</button>
      </div>

      <div class="table-container">
        <table class="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Source</th>
              <th>Destination</th>
              <th>Distance</th>
              <th>Est. Duration</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            ${res.routes.map(r => `
              <tr>
                <td>#${r.id}</td>
                <td><strong>${r.source}</strong></td>
                <td><strong>${r.destination}</strong></td>
                <td>${r.distance_km} km</td>
                <td>${r.estimated_duration}</td>
                <td>
                  <button class="btn btn-secondary btn-sm" onclick="openEditRouteModal(${r.id}, ${r.distance_km}, '${r.estimated_duration}')">Edit</button>
                  <button class="btn btn-danger btn-sm" onclick="deleteRoute(${r.id})">Delete</button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function openAddRouteModal() {
  const modal = document.getElementById('admin-action-modal');
  const title = document.getElementById('admin-modal-title');
  const body = document.getElementById('admin-modal-body');

  title.innerText = 'Add New Route';
  body.innerHTML = `
    <form onsubmit="handleAddRoute(event)">
      <div class="form-group" style="margin-bottom: 1rem;">
        <label>Source City</label>
        <input type="text" class="form-control" id="modal-route-source" placeholder="e.g. Pune" required />
      </div>
      <div class="form-group" style="margin-bottom: 1rem;">
        <label>Destination City</label>
        <input type="text" class="form-control" id="modal-route-dest" placeholder="e.g. Goa" required />
      </div>
      <div class="form-group" style="margin-bottom: 1rem;">
        <label>Distance (km)</label>
        <input type="number" step="0.1" class="form-control" id="modal-route-dist" placeholder="e.g. 450" required />
      </div>
      <div class="form-group" style="margin-bottom: 1.5rem;">
        <label>Estimated Duration</label>
        <input type="text" class="form-control" id="modal-route-duration" placeholder="e.g. 8h 30m" required />
      </div>
      <button type="submit" class="btn btn-primary" style="width: 100%;">Create Route</button>
    </form>
  `;
  modal.classList.add('active');
}

async function handleAddRoute(e) {
  e.preventDefault();
  const source = document.getElementById('modal-route-source').value.trim();
  const destination = document.getElementById('modal-route-dest').value.trim();
  const distance_km = document.getElementById('modal-route-dist').value;
  const estimated_duration = document.getElementById('modal-route-duration').value.trim();

  try {
    await API.post('/api/admin/routes', { source, destination, distance_km, estimated_duration });
    closeAdminModal();
    showToast('Route created successfully!', 'success');
    await loadRoutes();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function openEditRouteModal(id, distance, duration) {
  const modal = document.getElementById('admin-action-modal');
  const title = document.getElementById('admin-modal-title');
  const body = document.getElementById('admin-modal-body');

  title.innerText = `Edit Route #${id}`;
  body.innerHTML = `
    <form onsubmit="handleEditRoute(event, ${id})">
      <div class="form-group" style="margin-bottom: 1rem;">
        <label>Distance (km)</label>
        <input type="number" step="0.1" class="form-control" id="modal-edit-route-dist" value="${distance}" required />
      </div>
      <div class="form-group" style="margin-bottom: 1.5rem;">
        <label>Estimated Duration</label>
        <input type="text" class="form-control" id="modal-edit-route-dur" value="${duration}" required />
      </div>
      <button type="submit" class="btn btn-primary" style="width: 100%;">Save Changes</button>
    </form>
  `;
  modal.classList.add('active');
}

async function handleEditRoute(e, id) {
  e.preventDefault();
  const distance_km = document.getElementById('modal-edit-route-dist').value;
  const estimated_duration = document.getElementById('modal-edit-route-dur').value.trim();

  try {
    await API.put(`/api/admin/routes/${id}`, { distance_km, estimated_duration });
    closeAdminModal();
    showToast('Route updated successfully!', 'success');
    await loadRoutes();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function deleteRoute(id) {
  if (!confirm(`Are you sure you want to delete Route #${id}?`)) return;
  try {
    await API.delete(`/api/admin/routes/${id}`);
    showToast('Route deleted successfully.', 'info');
    await loadRoutes();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// --------------------------------------------------------------------
// 4. SCHEDULES MANAGEMENT
// --------------------------------------------------------------------
async function loadSchedules() {
  const container = document.getElementById('admin-tab-content');
  try {
    const [schedRes, busRes, routeRes] = await Promise.all([
      API.get('/api/admin/schedules'),
      API.get('/api/admin/buses'),
      API.get('/api/admin/routes')
    ]);

    allBuses = busRes.buses;
    allRoutes = routeRes.routes;

    container.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem;">
        <h3 style="font-size: 1.25rem;">Departure Schedules (${schedRes.schedules.length})</h3>
        <button class="btn btn-primary btn-sm" onclick="openAddScheduleModal()">+ Schedule New Trip</button>
      </div>

      <div class="table-container">
        <table class="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Route</th>
              <th>Bus</th>
              <th>Departure</th>
              <th>Arrival</th>
              <th>Fare</th>
              <th>Booked / Total</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            ${schedRes.schedules.map(s => `
              <tr>
                <td>#${s.id}</td>
                <td><strong>${s.source} ➔ ${s.destination}</strong></td>
                <td>${s.bus_name} (${s.bus_number})</td>
                <td>${formatDateTime(s.departure_time)}</td>
                <td>${formatDateTime(s.arrival_time)}</td>
                <td><strong>${formatCurrency(s.fare)}</strong></td>
                <td>${s.booked_seats} / ${s.total_seats}</td>
                <td>
                  <span class="badge ${s.status === 'scheduled' ? 'badge-success' : (s.status === 'completed' ? 'badge-info' : 'badge-danger')}">
                    ${s.status}
                  </span>
                </td>
                <td>
                  <button class="btn btn-danger btn-sm" onclick="deleteSchedule(${s.id})">Delete</button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function openAddScheduleModal() {
  const modal = document.getElementById('admin-action-modal');
  const title = document.getElementById('admin-modal-title');
  const body = document.getElementById('admin-modal-body');

  title.innerText = 'Schedule New Trip';
  body.innerHTML = `
    <form onsubmit="handleAddSchedule(event)">
      <div class="form-group" style="margin-bottom: 1rem;">
        <label>Select Route</label>
        <select class="form-control" id="modal-sched-route" required>
          ${allRoutes.map(r => `<option value="${r.id}">${r.source} ➔ ${r.destination} (${r.distance_km} km)</option>`).join('')}
        </select>
      </div>
      <div class="form-group" style="margin-bottom: 1rem;">
        <label>Select Bus</label>
        <select class="form-control" id="modal-sched-bus" required>
          ${allBuses.map(b => `<option value="${b.id}">${b.bus_name} - ${b.bus_number} (${b.bus_type})</option>`).join('')}
        </select>
      </div>
      <div class="form-group" style="margin-bottom: 1rem;">
        <label>Departure Date & Time</label>
        <input type="datetime-local" class="form-control" id="modal-sched-dep" required />
      </div>
      <div class="form-group" style="margin-bottom: 1rem;">
        <label>Arrival Date & Time</label>
        <input type="datetime-local" class="form-control" id="modal-sched-arr" required />
      </div>
      <div class="form-group" style="margin-bottom: 1.5rem;">
        <label>Ticket Fare (₹)</label>
        <input type="number" step="1" class="form-control" id="modal-sched-fare" placeholder="e.g. 650" required />
      </div>
      <button type="submit" class="btn btn-primary" style="width: 100%;">Create Schedule</button>
    </form>
  `;
  modal.classList.add('active');
}

async function handleAddSchedule(e) {
  e.preventDefault();
  const route_id = document.getElementById('modal-sched-route').value;
  const bus_id = document.getElementById('modal-sched-bus').value;
  let departure_time = document.getElementById('modal-sched-dep').value.replace('T', ' ') + ':00';
  let arrival_time = document.getElementById('modal-sched-arr').value.replace('T', ' ') + ':00';
  const fare = document.getElementById('modal-sched-fare').value;

  try {
    await API.post('/api/admin/schedules', { bus_id, route_id, departure_time, arrival_time, fare });
    closeAdminModal();
    showToast('Schedule created successfully!', 'success');
    await loadSchedules();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function deleteSchedule(id) {
  if (!confirm(`Are you sure you want to delete Schedule #${id}?`)) return;
  try {
    await API.delete(`/api/admin/schedules/${id}`);
    showToast('Schedule deleted.', 'info');
    await loadSchedules();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// --------------------------------------------------------------------
// 5. ALL BOOKINGS VIEW
// --------------------------------------------------------------------
async function loadBookings() {
  const container = document.getElementById('admin-tab-content');
  try {
    const res = await API.get('/api/admin/bookings');

    container.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem;">
        <h3 style="font-size: 1.25rem;">System Bookings (${res.bookings.length})</h3>
      </div>

      <div class="table-container">
        <table class="table">
          <thead>
            <tr>
              <th>PNR</th>
              <th>Customer</th>
              <th>Route</th>
              <th>Bus</th>
              <th>Departure</th>
              <th>Seats</th>
              <th>Total Fare</th>
              <th>Status</th>
              <th>Payment</th>
            </tr>
          </thead>
          <tbody>
            ${res.bookings.map(b => `
              <tr>
                <td><strong>${b.pnr}</strong></td>
                <td>
                  <div>${b.user_name}</div>
                  <div style="font-size: 0.75rem; color: var(--gray-400);">${b.user_email} • ${b.user_phone}</div>
                </td>
                <td>${b.source} ➔ ${b.destination}</td>
                <td>${b.bus_name}</td>
                <td>${formatDateTime(b.departure_time)}</td>
                <td>
                  <span title="${b.passengers.map(p => `${p.passenger_name} (Seat ${p.seat_number})`).join(', ')}">
                    ${b.passengers.map(p => p.seat_number).join(', ')} (${b.passengers.length})
                  </span>
                </td>
                <td><strong>${formatCurrency(b.total_fare)}</strong></td>
                <td>
                  <span class="badge ${b.booking_status === 'CONFIRMED' ? 'badge-success' : 'badge-danger'}">
                    ${b.booking_status}
                  </span>
                </td>
                <td>
                  <div style="font-size: 0.8rem; font-weight: 600;">${b.payment_status}</div>
                  ${b.refund_amount > 0 ? `<div style="font-size: 0.75rem; color: var(--danger);">Refund: ${formatCurrency(b.refund_amount)}</div>` : ''}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function closeAdminModal() {
  const modal = document.getElementById('admin-action-modal');
  if (modal) modal.classList.remove('active');
}
