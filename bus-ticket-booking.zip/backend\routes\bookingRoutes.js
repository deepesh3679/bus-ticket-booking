const express = require('express');
const router = express.Router();
const {
  createBooking,
  getUserBookings,
  getBookingByPNR,
  cancelBooking
} = require('../controllers/bookingController');
const { verifyToken } = require('../middleware/auth');

// All booking routes require authenticated user
router.use(verifyToken);

router.post('/', createBooking);
router.get('/my-bookings', getUserBookings);
router.get('/pnr/:pnr', getBookingByPNR);
router.post('/:bookingId/cancel', cancelBooking);

module.exports = router;
