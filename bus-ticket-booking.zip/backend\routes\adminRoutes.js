const express = require('express');
const router = express.Router();
const {
  getDashboardStats,
  getAllBuses,
  addBus,
  editBus,
  deleteBus,
  getAllRoutes,
  addRoute,
  editRoute,
  deleteRoute,
  getAllSchedules,
  addSchedule,
  editSchedule,
  deleteSchedule,
  getAllBookings
} = require('../controllers/adminController');
const { verifyToken, requireAdmin } = require('../middleware/auth');

// All Admin routes require authentication + admin role
router.use(verifyToken, requireAdmin);

// Dashboard
router.get('/stats', getDashboardStats);

// Buses
router.get('/buses', getAllBuses);
router.post('/buses', addBus);
router.put('/buses/:id', editBus);
router.delete('/buses/:id', deleteBus);

// Routes
router.get('/routes', getAllRoutes);
router.post('/routes', addRoute);
router.put('/routes/:id', editRoute);
router.delete('/routes/:id', deleteRoute);

// Schedules
router.get('/schedules', getAllSchedules);
router.post('/schedules', addSchedule);
router.put('/schedules/:id', editSchedule);
router.delete('/schedules/:id', deleteSchedule);

// Bookings
router.get('/bookings', getAllBookings);

module.exports = router;
